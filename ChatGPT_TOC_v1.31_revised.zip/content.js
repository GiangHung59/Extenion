// Phiên bản: AutoUpdateTOC_v6 2025-04-21 02:15:00
// Tính năng: Tự động cập nhật mục lục khi người dùng gửi tin nhắn và AI trả lời, lưu vị trí cuộn, lưu trạng thái ẩn/hiện panel trên đám mây, tô sáng mục liên quan, ẩn nút Refresh, phân cấp tiêu đề h1/h2/h3 với biểu tượng, giữ cuộn theo trang, bỏ cuộn tự động khi AI trả lời, tìm kiếm với nút xóa
(function () {
  "use strict";

  const panelId = "chatgpt-toc-panel";
  const toggleId = "chatgpt-toc-toggle";
  const resizeHandleId = "chatgpt-toc-resize";
  const dragHandleId = "chatgpt-toc-drag";
  const dragHandleBottomId = "chatgpt-toc-drag-bottom";
  const removeOld = () => {
    const oldPanel = document.getElementById(panelId);
    const oldToggle = document.getElementById(toggleId);
    const oldResize = document.getElementById(resizeHandleId);
    const oldDrag = document.getElementById(dragHandleId);
    const oldDragBottom = document.getElementById(dragHandleBottomId);
    if (oldPanel) oldPanel.remove();
    if (oldToggle) oldToggle.remove();
    if (oldResize) oldResize.remove();
    if (oldDrag) oldDrag.remove();
    if (oldDragBottom) oldDragBottom.remove();
  };

  const isDark = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)").matches : false;

  const colors = {
    bg: isDark ? "#1e1e1e" : "#ffffff",
    text: isDark ? "#eee" : "#111",
    border: isDark ? "#555" : "#ccc",
    active: isDark ? "#444" : "#ddd",
    highlight: isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)"
  };

  let panelWidth, panelTop, panelHeight, panelBottom;
  let isPanelOpen = false;
  let isRefreshing = false;
  let language = "vi"; // Default language: Vietnamese
  let theme = "auto"; // Default theme: Auto (follow browser)

  // Debounce function to limit execution frequency
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  chrome.storage.sync.get([
    "chatgpt-toc-panel-width",
    "chatgpt-toc-panel-top",
    "chatgpt-toc-panel-height",
    "chatgpt-toc-panel-open",
    "chatgpt-toc-language",
    "chatgpt-toc-theme"
  ], (result) => {
    panelWidth = parseInt(result["chatgpt-toc-panel-width"]) || 400;
    panelTop = parseInt(result["chatgpt-toc-panel-top"]) || 57;
    panelHeight = parseInt(result["chatgpt-toc-panel-height"]) || null;
    panelBottom = panelHeight ? (panelTop + panelHeight) : window.innerHeight;
    isPanelOpen = result["chatgpt-toc-panel-open"] || false;
    language = result["chatgpt-toc-language"] || "vi";
    theme = result["chatgpt-toc-theme"] || "auto";
    createTOC();
  });

  // Translations
  const translations = {
    en: {
      myQuestions: "🧑‍💻 My Questions",
      aiResponses: "🤖 AI Responses",
      search: "Search...",
      settings: "Settings",
      language: "Language:",
      english: "English",
      vietnamese: "Vietnamese",
      theme: "Theme:",
      light: "Light",
      dark: "Dark",
      auto: "Auto (follow browser)",
      save: "Save",
      cancel: "Cancel",
      noResults: "No results found"
    },
    vi: {
      myQuestions: "🧑‍💻 Tôi hỏi",
      aiResponses: "🤖 AI trả lời",
      search: "Tìm kiếm...",
      settings: "Cài đặt",
      language: "Ngôn ngữ:",
      english: "Tiếng Anh",
      vietnamese: "Tiếng Việt",
      theme: "Chế độ:",
      light: "Sáng",
      dark: "Tối",
      auto: "Tự động (theo trình duyệt)",
      save: "Lưu",
      cancel: "Hủy",
      noResults: "Không tìm thấy kết quả"
    }
  };

  // Get translation based on current language
  function t(key) {
    return translations[language][key] || key;
  }

  // Apply theme
  function applyTheme() {
    let isDarkTheme;
    
    if (theme === "auto") {
      isDarkTheme = window.matchMedia("(prefers-color-scheme: dark)").matches;
    } else {
      isDarkTheme = theme === "dark";
    }
    
    colors.bg = isDarkTheme ? "#1e1e1e" : "#ffffff";
    colors.text = isDarkTheme ? "#eee" : "#111";
    colors.border = isDarkTheme ? "#555" : "#ccc";
    colors.active = isDarkTheme ? "#444" : "#ddd";
    colors.highlight = isDarkTheme ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)";
    
    return isDarkTheme;
  }

  function createTOC() {
    removeOld();
    
    // Apply current theme
    const isDarkTheme = applyTheme();

    const panel = document.createElement("div");
    panel.id = panelId;
    panel.style.fontSize = "12px";
    panel.style.top = `${panelTop}px`;
    panel.style.right = isPanelOpen ? "0px" : `-${panelWidth}px`;
    panel.style.width = `${panelWidth}px`;
    panel.style.height = panelHeight ? `${panelHeight}px` : `calc(100vh - ${panelTop}px)`;
    panel.style.backgroundColor = colors.bg;
    panel.style.color = colors.text;

    const resizeHandle = document.createElement("div");
    resizeHandle.id = resizeHandleId;
    resizeHandle.style.top = `${panelTop}px`;
    resizeHandle.style.height = panelHeight ? `${panelHeight}px` : `calc(100vh - ${panelTop}px)`;
    resizeHandle.style.right = isPanelOpen ? `${panelWidth}px` : `-${3 + panelWidth}px`;

    const dragHandle = document.createElement("div");
    dragHandle.id = dragHandleId;

    const dragHandleBottom = document.createElement("div");
    dragHandleBottom.id = dragHandleBottomId;

    // Tạo nút TOC (không đổi giao diện, chỉ xử lý vị trí và phím tắt)
    const toggle = document.createElement("button");
    toggle.id = toggleId;
    toggle.textContent = "TOC";
    // Đặt vị trí top để luôn ở giữa panel (sử dụng transform để căn giữa thật sự)
    const updateTogglePos = () => {
      const ph = panelHeight ? panelHeight : (window.innerHeight - panelTop);
      toggle.style.top = `${panelTop + ph / 2}px`;
      toggle.style.transform = "translateY(-50%)";
    };
    updateTogglePos();
    toggle.style.right = isPanelOpen ? `${panelWidth + 3}px` : "0px";
    toggle.style.position = "fixed";
    // Các style khác giữ nguyên mặc định (giao diện gốc)

    panel.appendChild(resizeHandle);
    panel.appendChild(dragHandle);
    panel.appendChild(dragHandleBottom);
    document.body.appendChild(toggle);

    // Create settings button
    const settingsBtn = document.createElement("button");
    settingsBtn.textContent = "⚙️";
    settingsBtn.title = t("settings");
    settingsBtn.style.position = "absolute";
    settingsBtn.style.top = "5px";
    settingsBtn.style.right = "5px";
    settingsBtn.style.background = "none";
    settingsBtn.style.border = "none";
    settingsBtn.style.fontSize = "16px";
    settingsBtn.style.cursor = "pointer";
    settingsBtn.style.color = colors.text;
    panel.appendChild(settingsBtn);

    // Create settings panel (initially hidden)
    const settingsPanel = document.createElement("div");
    settingsPanel.className = "toc-settings-panel";
    settingsPanel.style.position = "absolute";
    settingsPanel.style.top = "0";
    settingsPanel.style.left = "0";
    settingsPanel.style.width = "100%";
    settingsPanel.style.height = "100%";
    settingsPanel.style.backgroundColor = colors.bg;
    settingsPanel.style.zIndex = "1000";
    settingsPanel.style.padding = "20px";
    settingsPanel.style.boxSizing = "border-box";
    settingsPanel.style.display = "none";
    
    // Settings content
    const settingsTitle = document.createElement("h3");
    settingsTitle.textContent = t("settings");
    settingsTitle.style.marginTop = "0";
    settingsTitle.style.marginBottom = "20px";
    settingsPanel.appendChild(settingsTitle);
    
    // Language selection
    const langLabel = document.createElement("div");
    langLabel.textContent = t("language");
    langLabel.style.marginBottom = "5px";
    langLabel.style.fontWeight = "bold";
    settingsPanel.appendChild(langLabel);
    
    const langSelect = document.createElement("select");
    langSelect.style.width = "100%";
    langSelect.style.padding = "5px";
    langSelect.style.marginBottom = "15px";
    langSelect.style.backgroundColor = colors.bg;
    langSelect.style.color = colors.text;
    langSelect.style.border = `1px solid ${colors.border}`;
    
    const enOption = document.createElement("option");
    enOption.value = "en";
    enOption.textContent = t("english");
    langSelect.appendChild(enOption);
    
    const viOption = document.createElement("option");
    viOption.value = "vi";
    viOption.textContent = t("vietnamese");
    langSelect.appendChild(viOption);
    
    langSelect.value = language;
    settingsPanel.appendChild(langSelect);
    
    // Theme selection
    const themeLabel = document.createElement("div");
    themeLabel.textContent = t("theme");
    themeLabel.style.marginBottom = "5px";
    themeLabel.style.fontWeight = "bold";
    settingsPanel.appendChild(themeLabel);
    
    const themeSelect = document.createElement("select");
    themeSelect.style.width = "100%";
    themeSelect.style.padding = "5px";
    themeSelect.style.marginBottom = "20px";
    themeSelect.style.backgroundColor = colors.bg;
    themeSelect.style.color = colors.text;
    themeSelect.style.border = `1px solid ${colors.border}`;
    
    const lightOption = document.createElement("option");
    lightOption.value = "light";
    lightOption.textContent = t("light");
    themeSelect.appendChild(lightOption);
    
    const darkOption = document.createElement("option");
    darkOption.value = "dark";
    darkOption.textContent = t("dark");
    themeSelect.appendChild(darkOption);
    
    const autoOption = document.createElement("option");
    autoOption.value = "auto";
    autoOption.textContent = t("auto");
    themeSelect.appendChild(autoOption);
    
    themeSelect.value = theme;
    settingsPanel.appendChild(themeSelect);
    
    // Buttons container
    const btnContainer = document.createElement("div");
    btnContainer.style.display = "flex";
    btnContainer.style.justifyContent = "space-between";
    
    // Save button
    const saveBtn = document.createElement("button");
    saveBtn.textContent = t("save");
    saveBtn.style.padding = "8px 15px";
    saveBtn.style.backgroundColor = isDarkTheme ? "#2563eb" : "#3b82f6";
    saveBtn.style.color = "#ffffff";
    saveBtn.style.border = "none";
    saveBtn.style.borderRadius = "4px";
    saveBtn.style.cursor = "pointer";
    
    // Cancel button
    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = t("cancel");
    cancelBtn.style.padding = "8px 15px";
    cancelBtn.style.backgroundColor = "transparent";
    cancelBtn.style.color = colors.text;
    cancelBtn.style.border = `1px solid ${colors.border}`;
    cancelBtn.style.borderRadius = "4px";
    cancelBtn.style.cursor = "pointer";
    
    btnContainer.appendChild(cancelBtn);
    btnContainer.appendChild(saveBtn);
    settingsPanel.appendChild(btnContainer);
    
    // Add settings panel to main panel
    panel.appendChild(settingsPanel);
    
    // Settings button click handler
    settingsBtn.addEventListener("click", () => {
      settingsPanel.style.display = "block";
    });
    
    // Cancel button click handler
    cancelBtn.addEventListener("click", () => {
      settingsPanel.style.display = "none";
      langSelect.value = language;
      themeSelect.value = theme;
    });
    
    // Save button click handler
    saveBtn.addEventListener("click", () => {
      const newLanguage = langSelect.value;
      const newTheme = themeSelect.value;
      
      // Save settings to storage
      chrome.storage.sync.set({
        "chatgpt-toc-language": newLanguage,
        "chatgpt-toc-theme": newTheme
      });
      
      // Update variables
      language = newLanguage;
      theme = newTheme;
      
      // Hide settings panel
      settingsPanel.style.display = "none";
      
      // Recreate TOC with new settings
      createTOC();
    });

    const tabTable = document.createElement("table");
    const tabRow = document.createElement("tr");
    const tdUser = document.createElement("td");
    const tdRefresh = document.createElement("td");
    const tdAI = document.createElement("td");

    const btnUser = document.createElement("button");
    const btnRefresh = document.createElement("button");
    const btnAI = document.createElement("button");

    btnUser.textContent = t("myQuestions");
    btnAI.textContent = t("aiResponses");
    btnRefresh.textContent = "🔄";
    btnUser.style.fontSize = "15px";
    btnAI.style.fontSize = "15px";
    btnRefresh.style.fontSize = "16px";

    tdUser.appendChild(btnUser);
    tdRefresh.appendChild(btnRefresh);
    tdAI.appendChild(btnAI);
    tdRefresh.style.display = "none"; // Ẩn nút Refresh
    tabRow.appendChild(tdUser);
    tabRow.appendChild(tdRefresh);
    tabRow.appendChild(tdAI);
    tabTable.appendChild(tabRow);
    panel.appendChild(tabTable);

    const containerUser = document.createElement("div");
    const containerAI = document.createElement("div");
    containerUser.style.display = "none";
    containerAI.style.display = "none";
    containerUser.style.paddingLeft = "6px";
    containerUser.style.paddingTop = "10px";
    containerUser.style.paddingBottom = "20px";
    containerUser.style.flexGrow = "1";
    containerUser.style.overflowY = "auto";
    containerAI.style.paddingLeft = "6px";
    containerAI.style.paddingTop = "10px";
    containerAI.style.paddingBottom = "20px";
    containerAI.style.flexGrow = "1";
    containerAI.style.overflowY = "auto";
    panel.appendChild(containerUser);
    panel.appendChild(containerAI);

    // Create custom context menu
    const contextMenu = document.createElement("div");
    contextMenu.className = "toc-context-menu";
    contextMenu.style.position = "absolute";
    contextMenu.style.zIndex = "10000";
    contextMenu.style.backgroundColor = colors.bg;
    contextMenu.style.border = `1px solid ${colors.border}`;
    contextMenu.style.borderRadius = "4px";
    contextMenu.style.boxShadow = "0 2px 10px rgba(0,0,0,0.2)";
    contextMenu.style.display = "none";
    document.body.appendChild(contextMenu);
    
    // Add menu item
    const addToTOCItem = document.createElement("div");
    addToTOCItem.textContent = "Thêm vào mục lục";
    addToTOCItem.style.padding = "8px 12px";
    addToTOCItem.style.cursor = "pointer";
    addToTOCItem.style.color = colors.text;
    
    addToTOCItem.addEventListener("mouseover", () => {
      addToTOCItem.style.backgroundColor = colors.highlight;
    });
    
    addToTOCItem.addEventListener("mouseout", () => {
      addToTOCItem.style.backgroundColor = "transparent";
    });
    
    contextMenu.appendChild(addToTOCItem);

    // Add search box to the bottom of the TOC panel
    const searchContainer = document.createElement("div");
    searchContainer.className = "toc-search-container";
    searchContainer.style.padding = "5px";
    searchContainer.style.borderTop = `1px solid ${colors.border}`;
    searchContainer.style.position = "sticky";
    searchContainer.style.bottom = "0";
    searchContainer.style.backgroundColor = colors.bg;
    searchContainer.style.zIndex = "100";
    searchContainer.style.display = "flex";
    searchContainer.style.alignItems = "center";
    
    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.placeholder = t("search");
    searchInput.className = "toc-search-input";
    searchInput.style.flex = "1";
    searchInput.style.padding = "5px";
    searchInput.style.boxSizing = "border-box";
    searchInput.style.border = `1px solid ${colors.border}`;
    searchInput.style.borderRadius = "4px";
    searchInput.style.backgroundColor = colors.bg;
    searchInput.style.color = colors.text;
    
    // Add clear button
    const clearBtn = document.createElement("button");
    clearBtn.textContent = "✕";
    clearBtn.style.marginLeft = "5px";
    clearBtn.style.padding = "5px 8px";
    clearBtn.style.backgroundColor = "transparent";
    clearBtn.style.border = "none";
    clearBtn.style.borderRadius = "4px";
    clearBtn.style.cursor = "pointer";
    clearBtn.style.color = colors.text;
    clearBtn.style.fontSize = "14px";
    clearBtn.style.display = "none"; // Initially hidden
    
    clearBtn.addEventListener("click", () => {
      searchInput.value = "";
      clearBtn.style.display = "none";
      // Trigger the input event to update the search results
      searchInput.dispatchEvent(new Event("input"));
    });
    
    searchContainer.appendChild(searchInput);
    searchContainer.appendChild(clearBtn);
    panel.appendChild(searchContainer);

    let linksMap = new Map();
    let lastMessageCount = 0;
    let lastAssistantContent = "";
    let lastScrollTop = 0;
    let customEntries = JSON.parse(localStorage.getItem("chatgpt-toc-custom-entries") || "[]");

    function buildTOC() {
      const activeContainer = containerUser.style.display === "block" ? containerUser : containerAI;
      lastScrollTop = activeContainer.scrollTop;

      containerUser.innerHTML = "";
      containerAI.innerHTML = "";
      linksMap.clear();
      let turn = 0;
      const blocks = document.querySelectorAll('[data-message-author-role]');
      lastMessageCount = blocks.length;

      isRefreshing = true;

      let assistantContent = "";
      blocks.forEach((block) => {
        const role = block.getAttribute("data-message-author-role");
        const content = block.querySelector(".markdown");
        turn++;
        if (role === "user") {
          const id = `toc-user-${turn}`;
          block.id = id;
          const text = block.innerText.trim().split("\n")[0].slice(0, 100) || "(...)";
          const link = document.createElement("a");
          link.href = "#" + id;
          link.textContent = `💬 ${text}`;
          link.style.fontSize = "14px";
          link.style.display = "block";
          link.style.textDecoration = "none";
          link.style.color = colors.text;
          link.style.padding = "3px 0";
          link.style.borderBottom = `1px solid ${colors.border}`;
          
          containerUser.appendChild(link);
          linksMap.set(block, { link, position: block.offsetTop });

          link.addEventListener('click', (e) => {
            e.preventDefault();
            resetLinkStyles();
            highlightLink(link);
            document.querySelector(`#${id}`).scrollIntoView({ behavior: 'smooth' });
            if (!isElementInViewport(link, activeContainer)) {
              scrollPanelToLink(link, activeContainer);
            }
          });
        }
        if (role === "assistant" && content) {
          assistantContent += content.innerText;
          
          const headers = content.querySelectorAll("h1,h2,h3");
          const hasH1 = content.querySelector("h1") !== null;
          const hasH2 = content.querySelector("h2") !== null;
          
          headers.forEach((header, i) => {
            const id = `toc-ai-${turn}-${i}`;
            header.id = id;
            const link = document.createElement("a");
            link.href = "#" + id;
            link.style.display = "block";
            link.style.textDecoration = "none";
            link.style.color = colors.text;
            link.style.padding = "3px 0";
            link.style.borderBottom = `1px solid ${colors.border}`;
            
            if (header.tagName === "H1") {
              link.textContent = `📌 ${header.textContent}`; // Icon ghim cho h1
              link.style.marginLeft = "0px";
            } else if (header.tagName === "H2") {
              link.textContent = `➤ ${header.textContent}`; // Icon mũi tên cho h2
              link.style.marginLeft = hasH1 ? "10px" : "0px";
            } else if (header.tagName === "H3") {
              if (!hasH1 && !hasH2) {
                link.textContent = `📌 ${header.textContent}`; // Icon ghim như h1
                link.style.marginLeft = "0px";
              } else if (!hasH1 && hasH2) {
                link.textContent = `➤ ${header.textContent}`; // Icon mũi tên như h2
                link.style.marginLeft = "10px";
              } else {
                link.textContent = `◦ ${header.textContent}`; // Icon vòng tròn cho h3
                link.style.marginLeft = "20px";
              }
            }
            link.style.fontSize = "14px";
            
            containerAI.appendChild(link);
            linksMap.set(header, { link, position: header.offsetTop });

            link.addEventListener('click', (e) => {
              e.preventDefault();
              resetLinkStyles();
              highlightLink(link);
              document.querySelector(`#${id}`).scrollIntoView({ behavior: 'smooth' });
              if (!isElementInViewport(link, activeContainer)) {
                scrollPanelToLink(link, activeContainer);
              }
            });
          });
        }
      });
      lastAssistantContent = assistantContent;

      // Restore custom entries
      restoreCustomEntries();

      activeContainer.scrollTop = lastScrollTop;

      setTimeout(() => {
        isRefreshing = false;
      }, 500);

      setupScrollSync();
    }

    // Add custom entry to TOC
    function addCustomEntryToTOC(text, selection) {
      // Create a unique ID for this custom entry
      const customId = `toc-custom-${Date.now()}`;
      
      // Create a marker span at the selection
      const range = selection.getRangeAt(0);
      const marker = document.createElement("span");
      marker.id = customId;
      marker.className = "toc-custom-marker";
      marker.style.backgroundColor = "rgba(255, 255, 0, 0.2)";
      
      try {
        // Try to insert the marker at the selection
        range.surroundContents(marker);
        
        // Add entry to the TOC
        const customEntry = document.createElement("a");
        customEntry.href = `#${customId}`;
        customEntry.textContent = `✏️ ${text.length > 50 ? text.substring(0, 47) + "..." : text}`;
        customEntry.style.display = "block";
        customEntry.style.textDecoration = "none";
        customEntry.style.color = colors.text;
        customEntry.style.padding = "3px 0";
        customEntry.style.borderBottom = `1px solid ${colors.border}`;
        
        // Create a custom entries container if it doesn't exist
        let customContainer = document.getElementById("toc-custom-entries");
        if (!customContainer) {
          customContainer = document.createElement("div");
          customContainer.id = "toc-custom-entries";
          customContainer.style.padding = "5px";
          customContainer.style.marginTop = "10px";
          customContainer.style.borderTop = `1px solid ${colors.border}`;
          
          const customHeader = document.createElement("div");
          customHeader.textContent = "Mục tùy chỉnh";
          customHeader.style.fontWeight = "bold";
          customHeader.style.padding = "5px 0";
          customContainer.appendChild(customHeader);
          
          // Add to the active container
          const activeContainer = containerUser.style.display === "block" ? containerUser : containerAI;
          activeContainer.appendChild(customContainer);
        }
        
        // Add click handler
        customEntry.addEventListener("click", (e) => {
          e.preventDefault();
          document.querySelector(`#${customId}`).scrollIntoView({ behavior: 'smooth' });
          
          // Highlight all TOC entries
          resetLinkStyles();
          
          // Highlight this entry
          customEntry.style.backgroundColor = colors.highlight;
        });
        
        // Add remove button
        const removeBtn = document.createElement("span");
        removeBtn.textContent = "✕";
        removeBtn.style.marginLeft = "5px";
        removeBtn.style.cursor = "pointer";
        removeBtn.style.float = "right";
        
        removeBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          // Remove the marker from the text
          const markerElement = document.getElementById(customId);
          if (markerElement) {
            // Replace the marker with its text content
            const parent = markerElement.parentNode;
            const textNode = document.createTextNode(markerElement.textContent);
            parent.replaceChild(textNode, markerElement);
          }
          
          // Remove the entry from TOC
          customEntry.remove();
          
          // Remove from custom entries
          const idx = customEntries.findIndex(entry => entry.id === customId);
          if (idx !== -1) {
            customEntries.splice(idx, 1);
            localStorage.setItem("chatgpt-toc-custom-entries", JSON.stringify(customEntries));
          }
          
          // Remove the container if empty
          if (customContainer.querySelectorAll("a").length === 0) {
            customContainer.remove();
          }
        });
        
        customEntry.appendChild(removeBtn);
        customContainer.appendChild(customEntry);
        
        // Save custom entry to localStorage
        customEntries.push({ id: customId, text });
        localStorage.setItem("chatgpt-toc-custom-entries", JSON.stringify(customEntries));
      } catch (e) {
        console.error("Could not create TOC entry from selection:", e);
        // Fallback for complex selections that can't be surrounded
        alert("Không thể thêm vào mục lục. Vui lòng chọn một đoạn văn bản đơn giản.");
      }
    }
    
    // Restore custom entries from localStorage
    function restoreCustomEntries() {
      if (customEntries.length === 0) return;
      
      // Create custom container
      let customContainer = document.getElementById("toc-custom-entries");
      if (!customContainer) {
        customContainer = document.createElement("div");
        customContainer.id = "toc-custom-entries";
        customContainer.style.padding = "5px";
        customContainer.style.marginTop = "10px";
        customContainer.style.borderTop = `1px solid ${colors.border}`;
        
        const customHeader = document.createElement("div");
        customHeader.textContent = "Mục tùy chỉnh";
        customHeader.style.fontWeight = "bold";
        customHeader.style.padding = "5px 0";
        customContainer.appendChild(customHeader);
        
        // Add to the active container
        const activeContainer = containerUser.style.display === "block" ? containerUser : containerAI;
        activeContainer.appendChild(customContainer);
      }
      
      // Add entries
      customEntries.forEach(entry => {
        // Check if the marker still exists
        const marker = document.getElementById(entry.id);
        if (!marker) return;
        
        const customEntry = document.createElement("a");
        customEntry.href = `#${entry.id}`;
        customEntry.textContent = `✏️ ${entry.text.length > 50 ? entry.text.substring(0, 47) + "..." : entry.text}`;
        customEntry.style.display = "block";
        customEntry.style.textDecoration = "none";
        customEntry.style.color = colors.text;
        customEntry.style.padding = "3px 0";
        customEntry.style.borderBottom = `1px solid ${colors.border}`;
        
        // Add click handler
        customEntry.addEventListener("click", (e) => {
          e.preventDefault();
          document.querySelector(`#${entry.id}`).scrollIntoView({ behavior: 'smooth' });
          
          // Highlight all TOC entries
          resetLinkStyles();
          
          // Highlight this entry
          customEntry.style.backgroundColor = colors.highlight;
        });
        
        // Add remove button
        const removeBtn = document.createElement("span");
        removeBtn.textContent = "✕";
        removeBtn.style.marginLeft = "5px";
        removeBtn.style.cursor = "pointer";
        removeBtn.style.float = "right";
        
        removeBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          // Remove the marker from the text
          const markerElement = document.getElementById(entry.id);
          if (markerElement) {
            // Replace the marker with its text content
            const parent = markerElement.parentNode;
            const textNode = document.createTextNode(markerElement.textContent);
            parent.replaceChild(textNode, markerElement);
          }
          
          // Remove the entry from TOC
          customEntry.remove();
          
          // Remove from custom entries
          const idx = customEntries.findIndex(e => e.id === entry.id);
          if (idx !== -1) {
            customEntries.splice(idx, 1);
            localStorage.setItem("chatgpt-toc-custom-entries", JSON.stringify(customEntries));
          }
          
          // Remove the container if empty
          if (customContainer.querySelectorAll("a").length === 0) {
            customContainer.remove();
          }
        });
        
        customEntry.appendChild(removeBtn);
        customContainer.appendChild(customEntry);
      });
    }

    // Handle context menu for text selection
    document.addEventListener("contextmenu", (e) => {
      const selection = window.getSelection();
      if (selection.toString().trim().length > 0) {
        // Only show our custom menu in ChatGPT content
        const chatContent = document.querySelector('[data-message-author-role]');
        if (chatContent && chatContent.contains(e.target)) {
          e.preventDefault();
          
          // Position the context menu
          contextMenu.style.left = `${e.pageX}px`;
          contextMenu.style.top = `${e.pageY}px`;
          contextMenu.style.display = "block";
          
          // Handle click on "Add to TOC"
          const handleAddToTOC = () => {
            const selectedText = selection.toString().trim();
            if (selectedText) {
              addCustomEntryToTOC(selectedText, selection);
            }
            hideContextMenu();
          };
          
          addToTOCItem.onclick = handleAddToTOC;
        }
      }
    });
    
    // Hide context menu when clicking elsewhere
    document.addEventListener("click", () => {
      hideContextMenu();
    });
    
    // Hide context menu when scrolling
    document.addEventListener("scroll", () => {
      hideContextMenu();
    });
    
    function hideContextMenu() {
      contextMenu.style.display = "none";
    }

    function resetLinkStyles() {
      linksMap.forEach(item => {
        item.link.style.background = "none";
        item.link.style.border = "none";
        item.link.style.color = colors.text;
      });
    }

    function highlightLink(link) {
      link.style.background = colors.highlight;
      link.style.border = `1px solid ${isDarkTheme ? "#60a5fa" : "#2563eb"}`;
      link.style.color = isDarkTheme ? "#ffffff" : "#000000";
    }

    function scrollPanelToLink(link, container) {
      const linkRect = link.getBoundingClientRect();
      const panelRect = container.getBoundingClientRect();
      const scrollTarget = (linkRect.top - panelRect.top + container.scrollTop) - (panelRect.height / 2) + (linkRect.height / 2);
      container.scrollTo({ top: scrollTarget, behavior: 'smooth' });
    }

    function isElementInViewport(el, container) {
      const rect = el.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      return rect.top >= containerRect.top && rect.bottom <= containerRect.bottom;
    }

    btnUser.onclick = () => {
      containerUser.style.display = "block";
      containerAI.style.display = "none";
      btnUser.style.background = colors.highlight;
      btnAI.style.background = colors.active;
    };
    btnAI.onclick = () => {
      containerUser.style.display = "none";
      containerAI.style.display = "block";
      btnUser.style.background = colors.active;
      btnAI.style.background = colors.highlight;
    };

    btnRefresh.onclick = () => {
      highlightObserver.disconnect();
      buildTOC();
      setupScrollSync();
    };

    function toggleTOC() {
      isPanelOpen = !isPanelOpen;
      if (isPanelOpen) {
        panel.style.right = "0px";
        resizeHandle.style.right = `${panelWidth}px`;
        toggle.style.right = `${panelWidth + 3}px`;
      } else {
        panel.style.right = `-${panelWidth}px`;
        resizeHandle.style.right = `-${3 + panelWidth}px`;
        toggle.style.right = "0px";
      }
      chrome.storage.sync.set({ "chatgpt-toc-panel-open": isPanelOpen });
    }

    toggle.onmouseover = () => {
      toggle.style.opacity = "1";
      toggle.style.boxShadow = "0 0 10px rgba(255,255,255,0.5)";
    };
    toggle.onmouseout = () => {
      toggle.style.opacity = "0.5";
      toggle.style.boxShadow = "none";
    };
    toggle.onclick = toggleTOC;

    // Hotkey ALT+S: luôn đồng bộ với chức năng toggleTOC
    document.addEventListener('keydown', (e) => {
      if (e.altKey && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        toggleTOC();
      }
    });

    let isResizing = false;
    resizeHandle.onmousedown = () => {
      isResizing = true;
      document.body.style.userSelect = "none";
    };

    let isDragging = false;
    dragHandle.onmousedown = () => {
      isDragging = true;
      document.body.style.userSelect = "none";
    };

    let isDraggingBottom = false;
    dragHandleBottom.onmousedown = () => {
      isDraggingBottom = true;
      document.body.style.userSelect = "none";
    };

    document.onmousemove = (e) => {
      if (isDragging) {
        const newTop = Math.max(0, Math.min(panelBottom - 200, e.clientY));
        const newHeight = panelBottom - newTop;
        panelTop = newTop;
        panelHeight = newHeight;
        panel.style.top = `${newTop}px`;
        panel.style.height = `${newHeight}px`;
        resizeHandle.style.top = `${newTop}px`;
        resizeHandle.style.height = `${newHeight}px`;
        updateTogglePos();
      } else if (isDraggingBottom) {
        const maxHeight = window.innerHeight * 0.95;
        const newHeight = Math.max(200, Math.min(maxHeight - panelTop, e.clientY - panelTop));
        panelHeight = newHeight;
        panelBottom = panelTop + newHeight;
        panel.style.height = `${newHeight}px`;
        resizeHandle.style.height = `${newHeight}px`;
        updateTogglePos();
      } else if (isResizing) {
        const newWidth = Math.max(200, Math.min(800, window.innerWidth - e.clientX));
        panelWidth = newWidth;
        panel.style.width = `${newWidth}px`;
        const isOpen = panel.style.right === "0px";
        resizeHandle.style.right = isOpen ? `${newWidth}px` : `-${newWidth + 3}px`;
        toggle.style.right = isOpen ? `${newWidth + 3}px` : "0px";
        updateTogglePos();
      }
    };

    document.onmouseup = () => {
      if (isDragging) {
        isDragging = false;
        document.body.style.userSelect = "";
        chrome.storage.sync.set({ "chatgpt-toc-panel-top": panelTop, "chatgpt-toc-panel-height": panelHeight });
      } else if (isDraggingBottom) {
        isDraggingBottom = false;
        document.body.style.userSelect = "";
        chrome.storage.sync.set({ "chatgpt-toc-panel-height": panelHeight });
      } else if (isResizing) {
        isResizing = false;
        document.body.style.userSelect = "";
        chrome.storage.sync.set({ "chatgpt-toc-panel-width": panelWidth });
      }
    };

    // Cập nhật vị trí TOC khi resize window
    window.addEventListener('resize', updateTogglePos);

    document.body.appendChild(panel);

    const observer = new MutationObserver((mutations, obs) => {
      const chatContainer = document.querySelector('[data-message-author-role]');
      if (chatContainer) {
        panel.style.right = isPanelOpen ? "0px" : `-${panelWidth}px`;
        resizeHandle.style.right = isPanelOpen ? `${panelWidth}px` : `-${3 + panelWidth}px`;
        toggle.style.right = isPanelOpen ? `${panelWidth + 3}px` : "0px";
        updateTogglePos();
        buildTOC();

        setInterval(() => {
          const currentMessageCount = document.querySelectorAll('[data-message-author-role]').length;
          let currentAssistantContent = "";
          document.querySelectorAll('[data-message-author-role="assistant"] .markdown').forEach((content) => {
            currentAssistantContent += content.innerText;
          });

          if (currentMessageCount !== lastMessageCount || currentAssistantContent !== lastAssistantContent) {
            buildTOC();
          }
        }, 2000);

        btnAI.click();
        setupScrollSync();
        obs.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    let lastUrl = location.href;
    new MutationObserver(() => {
      const currentUrl = location.href;
      if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        removeOld();
        setTimeout(createTOC, 100);
      }
    }).observe(document, { subtree: true, childList: true });

    function setupScrollSync() {
      const chatElements = document.querySelectorAll('[data-message-author-role]');
      if (!chatElements.length || linksMap.size === 0) return;

      let chatArea = chatElements[0].parentElement;
      while (chatArea && chatArea !== document.body && getComputedStyle(chatArea).overflowY !== "auto" && getComputedStyle(chatArea).overflowY !== "scroll") {
        chatArea = chatArea.parentElement;
      }
      if (!chatArea || chatArea === document.body) {
        chatArea = document.querySelector('div[class*="react-scroll-to-bottom"]') || document.querySelector('main') || document.body;
      }

      const activeContainer = () => containerUser.style.display === "block" ? containerUser : containerAI;

      const highlightObserver = new IntersectionObserver((entries) => {
        const container = activeContainer();
        if (!container || panel.style.right !== "0px" || isRefreshing) return;

        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const chatElement = entry.target;
            const { link } = linksMap.get(chatElement) || {};
            if (link) {
              resetLinkStyles();
              highlightLink(link);
            }
          }
        });
      }, {
        root: chatArea,
        threshold: 0.5
      });

      linksMap.forEach((item, chatElement) => {
        highlightObserver.observe(chatElement);
      });

      chatArea.addEventListener('scroll', () => {
        const container = activeContainer();
        if (!container || panel.style.right !== "0px" || linksMap.size === 0 || isRefreshing) return;

        const chatScrollHeight = chatArea.scrollHeight - chatArea.clientHeight;
        const chatScrollTop = chatArea.scrollTop;
        if (chatScrollHeight <= 0) return;

        const chatScrollRatio = chatScrollTop / chatScrollHeight;

        const tocScrollHeight = container.scrollHeight - container.clientHeight;
        if (tocScrollHeight <= 0) return;

        const tocScrollTarget = tocScrollHeight * chatScrollRatio;
        if (Math.abs(container.scrollTop - lastScrollTop) > 1) {
          container.scrollTop = tocScrollTarget;
        }
      });
    }
    
    // Add search functionality - real-time filtering as user types
    searchInput.addEventListener("input", function() {
      const searchTerm = this.value.toLowerCase();
      
      // Show/hide clear button based on search input
      if (searchTerm.length > 0) {
        clearBtn.style.display = "block";
      } else {
        clearBtn.style.display = "none";
      }
      
      const links = [...containerUser.querySelectorAll("a"), ...containerAI.querySelectorAll("a")];
      
      links.forEach(link => {
        const text = link.textContent.toLowerCase();
        
        if (searchTerm === "" || text.includes(searchTerm)) {
          link.style.display = "block";
          
          // Highlight matching text if search term is not empty
          if (searchTerm !== "") {
            const originalText = link.textContent;
            const index = originalText.toLowerCase().indexOf(searchTerm);
            if (index >= 0) {
              const before = originalText.substring(0, index);
              const match = originalText.substring(index, index + searchTerm.length);
              const after = originalText.substring(index + searchTerm.length);
              
              // Create a temporary element to hold the HTML content
              const tempElement = document.createElement('div');
              tempElement.innerHTML = `${before}<span style="background-color: yellow; color: black">${match}</span>${after}`;
              
              // Replace link content with highlighted version
              link.innerHTML = '';
              while (tempElement.firstChild) {
                link.appendChild(tempElement.firstChild);
              }
            }
          } else {
            // Restore original text format when search is cleared
            const iconMatch = link.textContent.match(/^([📌➤◦💬✏️]\s)/);
            const icon = iconMatch ? iconMatch[0] : "";
            const text = iconMatch ? link.textContent.substring(iconMatch[0].length) : link.textContent;
            
            link.innerHTML = `${icon}${text}`;
          }
        } else {
          link.style.display = "none";
        }
      });
      
      // Show "No results" message if no matches
      const visibleLinks = links.filter(link => link.style.display !== "none");
      let noResultsMsg = document.getElementById("toc-no-results");
      
      if (visibleLinks.length === 0 && searchTerm !== "") {
        if (!noResultsMsg) {
          noResultsMsg = document.createElement("div");
          noResultsMsg.id = "toc-no-results";
          noResultsMsg.textContent = t("noResults");
          noResultsMsg.style.padding = "10px";
          noResultsMsg.style.textAlign = "center";
          noResultsMsg.style.fontStyle = "italic";
          noResultsMsg.style.color = colors.text;
          
          const activeContainer = containerUser.style.display === "block" ? containerUser : containerAI;
          activeContainer.appendChild(noResultsMsg);
        }
      } else if (noResultsMsg) {
        noResultsMsg.remove();
      }
    });
  }
})();
