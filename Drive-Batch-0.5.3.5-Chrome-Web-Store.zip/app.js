import {initLanguage,t,message,onLanguageChange,sourceText} from './i18n.js';
import {installLanguageMenu} from './language-menu.js';
import {parseBatch, parseLink, splitName, displayName} from './core.js';
import {installIdleHide} from './idle-hide.js';
const $=id=>document.getElementById(id);
await initLanguage();
if(new URLSearchParams(location.search).get('overlay')!=='1'){const guide=document.querySelector('.download-tips summary [data-i18n]');guide.dataset.i18n='5';guide.textContent=t('5');}
let idleController;
const idleOwners=new Set();
function pauseIdle(owner){idleOwners.add(owner);idleController?.pause();}
function resumeIdle(owner){idleOwners.delete(owner);if(!idleOwners.size)idleController?.resume();}
let zipBusy=false;
let folderMessage='',appMessage='',inputResult=null;
function setAppMessage(value){appMessage=value;$('app-message').textContent=message(value);}
function renderInputResult(){if(inputResult){const {fresh,duplicates,errors}=inputResult;$('input-message').textContent=t('116',fresh)+(duplicates?' '+t('117',duplicates):'')+(errors.length?'\n'+errors.map(message).join('\n'):'');}}
let batch={items:[],paused:true},folder=null,folderItems=new Map(),folderBusy=false;
// TRÀ 0.5.3 — folder scan state. folderUnreadable: folders that failed, came
// back empty (indistinguishable from unreadable), or were cut off by a cap.
// Never rendered as "complete". scanToken discards stale scans replaced by a
// newer one; the background keeps the partial result of a cancelled scan.
let folderUnreadable=[],scanToken=0,scanCancelled=false,cancelScanBtn=null;
const prefixDrafts=new Map();
// HOA 0.5.3 — inline rename state (UI only; the name itself lives in batch
// storage via Trà's rename message, never in a draft alone).
const renameDrafts=new Map();
let renameEditingId=null;
const RENAME_LOCKED=['queued','preparing','downloading'];
function hasRealName(item){return !!item&&item.type!=='folder'&&!!item.actualName&&item.actualName!==item.id;}
function renameParts(item){
  if(item?.customBase)return {base:item.customBase,ext:item.customExt||''};
  const real=item?.actualName||item?.originalName||item?.name||'';
  return splitName(real);
}
async function saveRename(id){
  const base=(renameDrafts.get(id)??'').trim();
  const item=batch.items.find(i=>i.id===id);
  renameEditingId=null;renameDrafts.delete(id);
  if(!item){render();return;}
  if(!base){setAppMessage(t('157'));render();return;}
  const {ext}=renameParts(item);
  try{batch=await send('rename',{id,customBase:base.slice(0,160),customExt:ext});}
  catch(e){error(e);}
  render();
}
async function restoreRename(id){
  renameEditingId=null;renameDrafts.delete(id);
  try{batch=await send('rename',{id,clear:true});}
  catch(e){error(e);}
  render();
}
function formatSource(key,...args){return sourceText(key,...args);}
function setFolderMessage(value){folderMessage=value;$('folder-status').textContent=message(value);}
const local=globalThis.chrome?.storage?.local;
function saveDraft(){return local?.set({linkDraft:$('links').value}).catch(error);}
function saveFolder(){return local?.set({folderDraft:folder?{folder,items:[...folderItems.values()],message:folderMessage,unreadable:folderUnreadable}:null}).catch(error);}
// The cancel button is created here (app.js, scan logic) so index.html —
// Hoa's scope — needs no edit. Hoa: restyle/relocate freely, keep id
// "cancel-scan" or rebind to the same send('cancelScan') + scanCancelled flag.
function ensureCancelButton(){
  if(cancelScanBtn)return;
  const actions=document.querySelector('#folder-dialog .scan-actions');if(!actions)return;
  cancelScanBtn=element('button','');cancelScanBtn.type='button';cancelScanBtn.id='cancel-scan';cancelScanBtn.classList.add('cancel-scan');cancelScanBtn.textContent=t('132');cancelScanBtn.disabled=true;
  cancelScanBtn.addEventListener('click',()=>{scanCancelled=true;send('cancelScan').catch(()=>{});});
  actions.append(cancelScanBtn);
}
if(document.documentElement.classList.contains('popup')) {
  document.querySelector('h1').dataset.i18n='7';document.querySelector('h1').textContent=t('7');
  document.querySelector('header p').dataset.i18n='51';document.querySelector('header p').textContent=t('51');
}
$('links').addEventListener('input',saveDraft);
const types={file:'File gốc',folder:'Thư mục',document:'Word .docx',spreadsheets:'Excel .xlsx',presentation:'PowerPoint .pptx'};
async function send(type,extra={}) {const result=await chrome.runtime.sendMessage({type,...extra});if(result?.error)throw new Error(result.error);return result;}
function error(e) {setAppMessage(e.message||String(e));}
function element(tag,className,text) {const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=['file-name','file-url','user-content'].includes(className)?text:message(text);return el;}
function button(text,action) {const el=element('button','',text);el.addEventListener('click',()=>Promise.resolve().then(action).catch(error));return el;}
async function refresh(){batch=await send('get');render();}
function selected(){return batch.items.filter(i=>i.selected&&i.type!=='folder');}
function render() {
  const focused=document.activeElement;
  const editing=focused?.classList.contains('file-prefix')?{id:focused.dataset.id,start:focused.selectionStart,end:focused.selectionEnd}:null;
  const editingRename=focused?.classList.contains('rename-input')?{id:focused.dataset.id,start:focused.selectionStart,end:focused.selectionEnd}:null;
  const files=batch.items.filter(i=>i.type!=='folder');
  const count=selected().length;
  $('count').textContent=batch.items.length;
  $('summary').textContent=files.length?t('112',count,files.filter(i=>i.status==='done').length,files.filter(i=>['error','action'].includes(i.status)).length)+(batch.paused?' '+t('54'):''):t('16');
  $('empty').hidden=!!batch.items.length;$('table-wrap').hidden=!batch.items.length;
  $('select-all').checked=files.length>0&&count===files.length;$('select-all').indeterminate=count>0&&count<files.length;
  $('download').disabled=!selected().some(i=>!['done','downloading','queued','preparing'].includes(i.status));
  $('check').disabled=$('download').disabled;
  $('retry').disabled=!selected().some(i=>['error','action'].includes(i.status));
  $('stop').disabled=batch.paused||!files.some(i=>['queued','preparing','downloading'].includes(i.status));
  const fragment=document.createDocumentFragment();
  for(const item of batch.items) {
    const row=element('tr');
    const box=element('td');const input=element('input');input.type='checkbox';input.checked=item.selected;input.disabled=item.type==='folder';input.setAttribute('aria-label',t('113',item.name));
    input.addEventListener('change',()=>send('select',{ids:[item.id],selected:input.checked}).then(s=>{batch=s;render();}).catch(error));box.append(input);
    const name=element('td');
    const nameBox=element('div','file-name');
    if(item.type==='folder'){
      nameBox.textContent=`▱ ${item.name}`;
      name.append(nameBox);
    } else if(renameEditingId===item.id){
      const parts=renameParts(item);
      const input=element('input','rename-input');input.type='text';input.maxLength=160;
      input.dataset.id=item.id;input.value=renameDrafts.get(item.id)??parts.base;
      input.setAttribute('aria-label',t('154',displayName(item)));input.title=t('155');
      let saving=false;
      const commit=()=>{if(saving)return;saving=true;renameDrafts.set(item.id,input.value);saveRename(item.id);};
      input.addEventListener('input',()=>renameDrafts.set(item.id,input.value));
      input.addEventListener('keydown',e=>{
        if(e.key==='Enter'){e.preventDefault();commit();}
        else if(e.key==='Escape'){e.preventDefault();renameEditingId=null;renameDrafts.delete(item.id);render();}
      });
      input.addEventListener('blur',()=>commit());
      nameBox.append(input,element('span','rename-ext',parts.ext));
      name.append(nameBox,element('small','rename-hint',t('155')));
    } else {
      nameBox.textContent=displayName(item);
      if(hasRealName(item)){
        const locked=RENAME_LOCKED.includes(item.status);
        const edit=element('button','rename-btn','✏️');edit.type='button';
        edit.setAttribute('aria-label',t('151',displayName(item)));
        edit.title=locked?t('156'):t('151',displayName(item));edit.disabled=locked;
        edit.addEventListener('click',()=>{renameEditingId=item.id;renameDrafts.set(item.id,renameParts(item).base);render();});
        nameBox.append(document.createTextNode(' '),edit);
        if(item.customBase){
          const restore=element('button','rename-restore','↩');restore.type='button';
          restore.setAttribute('aria-label',t('153',item.originalName||item.actualName||''));
          restore.title=t('152');restore.disabled=locked;
          restore.addEventListener('click',()=>restoreRename(item.id));
          nameBox.append(document.createTextNode(' '),restore);
        }
      }
      name.append(nameBox);
    }
    if(item.type!=='folder') {
      const label=element('label','file-prefix-label','Thêm trước tên file');
      const prefix=element('input','file-prefix');prefix.type='text';prefix.maxLength=100;
      prefix.dataset.id=item.id;prefix.value=prefixDrafts.get(item.id)??item.prefix??'';
      prefix.placeholder=t('56');prefix.setAttribute('aria-label',t('114',item.name));
      prefix.disabled=['queued','preparing','downloading'].includes(item.status);
      prefix.addEventListener('input',()=>{
        prefixDrafts.set(item.id,prefix.value);
        send('prefix',{id:item.id,prefix:prefix.value}).catch(error);
      });
      label.append(prefix);name.prepend(label);
    }
    const link=element('a','file-url',item.url);link.href=item.url;link.target='_blank';link.rel='noreferrer';link.title=item.url;name.append(link);
    if(item.parent)name.append(element('small','file-url',t('115',item.parent)));
    const format=element('td','file-type',types[item.type]||'File');
    const status=element('td',`status ${item.status}`,item.type==='folder'?'Chọn cách tải thư mục':item.message);
    const actions=element('td');const group=element('div','row-actions');
    if(item.type==='folder')group.append(button('Chọn file',()=>openFolder(item)));
    group.append(button('Mở Google ↗',()=>send('open',{url:item.url})));
    if(item.status==='done'&&item.downloadId!==undefined)group.append(button('Hiện file',()=>chrome.downloads.show(item.downloadId)));
    actions.append(group);row.append(box,name,format,status,actions);fragment.append(row);
  }
  $('rows').replaceChildren(fragment);
  if(editing) {
    const input=[...$('rows').querySelectorAll('.file-prefix')].find(el=>el.dataset.id===editing.id);
    if(input&&!input.disabled){input.focus({preventScroll:true});input.setSelectionRange(editing.start,editing.end);}
  }
  if(renameEditingId) {
    const input=[...$('rows').querySelectorAll('.rename-input')].find(el=>el.dataset.id===renameEditingId);
    if(input){
      if(document.activeElement!==input)input.focus({preventScroll:true});
      if(editingRename&&editingRename.id===renameEditingId)input.setSelectionRange(editingRename.start,editingRename.end);
      else if(document.activeElement===input&&!editingRename)input.setSelectionRange(input.value.length,input.value.length);
    }
  }
}
function bind(id,action){$(id).addEventListener('click',async()=>{try{setAppMessage('');await action();}catch(e){error(e);}});}
bind('add',async()=>{
  const parsed=parseBatch($('links').value);
  const known=new Set(batch.items.map(i=>i.id));
  const fresh=parsed.items.filter(i=>!known.has(i.id));
  const duplicates=parsed.duplicates+parsed.items.length-fresh.length;
  batch=await send('add',{items:parsed.items});render();
  inputResult={fresh:fresh.length,duplicates,errors:parsed.errors};renderInputResult();
  if(!parsed.errors.length){$('links').value='';await saveDraft();}
  const firstFolder=fresh.find(i=>i.type==='folder');if(firstFolder)openFolder(firstFolder);
});
bind('select-all',async()=>{batch=await send('select',{ids:batch.items.map(i=>i.id),selected:$('select-all').checked});render();});
bind('check',async()=>{batch=await send('queue',{ids:selected().map(i=>i.id),mode:'check'});render();});
function prefixes(){return Object.fromEntries(batch.items.map(i=>[i.id,prefixDrafts.get(i.id)??i.prefix??'']));}
bind('download',async()=>{batch=await send('queue',{ids:selected().map(i=>i.id),mode:'download',prefixes:prefixes()});render();});
bind('retry',async()=>{batch=await send('queue',{ids:selected().filter(i=>['error','action'].includes(i.status)).map(i=>i.id),mode:'download',prefixes:prefixes()});render();});
bind('stop',async()=>{batch=await send('stop');render();setAppMessage(t('61'));});
bind('clear',async()=>{batch=await send('clear');for(const id of prefixDrafts.keys())if(!batch.items.some(i=>i.id===id))prefixDrafts.delete(id);render();});
function openFolder(item) {
  if(folderBusy)return;
  folder=item;folderItems=new Map();folderUnreadable=[];
  $('folder-name').textContent=item.name===item.id?t('38'):item.name;
  setFolderMessage(t('137'));
  ensureCancelButton();renderFolder();$('folder-dialog').showModal();pauseIdle('folder');
  saveFolder();
}
// Tree render: parent folders before their children (BFS discovery order),
// children indented by depth. Folders have no checkbox and are never counted
// as files to download; each folder row offers its own re-scan (embedded view
// or its open Drive tab) so a failed/pending subfolder can be retried alone.
function renderFolder() {
  const fragment=document.createDocumentFragment();
  for(const item of folderItems.values()) {
    const label=element('label','folder-entry');
    label.style.paddingLeft=`${((item.depth||1)-1)*18}px`;
    const box=element('input');box.type='checkbox';
    if(item.type==='folder'){box.disabled=true;box.checked=false;}
    else {box.checked=item.selected;box.addEventListener('change',()=>{item.selected=box.checked;renderFolder();saveFolder();});}
    const nameText=item.type==='folder'?`▱ ${item.name}`:item.name;
    const stateNote=item.type==='folder'?(item.scanState==='failed'?` · ${t('135')}`:item.scanState==='pending'?` · ${t('136')}`:''):'';
    const typeLabel=item.type==='file'?t('52'):item.type==='folder'?t('53'):types[item.type];
    label.append(box,element('span','user-content',nameText),element('small','',typeLabel+stateNote));
    if(item.type==='folder'){
      const sub=element('button','sub-scan');sub.type='button';sub.textContent=t('133');sub.disabled=folderBusy;
      sub.title=folderBusy?t('63'):'';
      sub.addEventListener('click',()=>scanSubfolder(item,false).catch(e=>setFolderMessage(e.message)));
      const subTab=element('button','sub-scan-tab');subTab.type='button';subTab.textContent=t('134');subTab.disabled=folderBusy;
      subTab.title=folderBusy?t('63'):'';
      subTab.addEventListener('click',()=>scanSubfolder(item,true).catch(e=>setFolderMessage(e.message)));
      label.append(sub,subTab);
    }
    fragment.append(label);
  }
  $('folder-items').replaceChildren(fragment);
  // Counts are FILES only: folders never count toward files to download.
  const files=[...folderItems.values()].filter(i=>i.type!=='folder');
  const selected=files.filter(i=>i.selected).length;
  $('folder-count').textContent=t('129',files.length,selected);
  $('folder-all').checked=files.length>0&&selected===files.length;$('folder-all').indeterminate=selected>0&&selected<files.length;
  $('import-folder').disabled=!selected||folderBusy;
}
function mergeFolder(items, opts={}) {
  if(!folder)return;
  for(const raw of items){
    try{
      const item=parseLink(raw.url);if(item.id===folder.id)continue;
      if(folderItems.has(item.id)){
        // Never overwrite a user's tick on re-scan; refresh folder scan state.
        const existing=folderItems.get(item.id);
        if(item.type==='folder'&&raw.scanState)existing.scanState=raw.scanState;
        continue;
      }
      const name=(raw.name||'').slice(0,500)||item.name;
      const depth=Number.isInteger(raw.depth)?raw.depth:(opts.depth||1);
      folderItems.set(item.id,{...item,name,selected:false,
        parent:raw.parent||opts.parent||folder.name,
        parentId:raw.parentId||opts.parentId||folder.id,depth,
        path:raw.path||((opts.path?opts.path+' › ':'')+name),
        scanState:item.type==='folder'?(raw.scanState||'pending'):undefined});
    }catch{}
  }
  if(opts.folderStates)for(const st of opts.folderStates){
    const node=folderItems.get(st.id);if(node)node.scanState=st.ok?'ok':'failed';
  }
  renderFolder();
}
function applyScanResult(result){
  if(!result)return;
  if(Array.isArray(result.unreadable))for(const u of result.unreadable){
    if(!folderUnreadable.some(x=>x.id===u.id))folderUnreadable.push(u);
  }
  // A folder that now scans OK leaves the unreadable list.
  if(Array.isArray(result.folderStates)){
    const okIds=new Set(result.folderStates.filter(s=>s.ok).map(s=>s.id));
    if(okIds.size)folderUnreadable=folderUnreadable.filter(u=>!okIds.has(u.id));
  }
  if(Array.isArray(result.entries))mergeFolder(result.entries,{folderStates:result.folderStates});
  else if(Array.isArray(result.items))mergeFolder(result.items,result.mergeOpts||{depth:1,parent:folder.name,parentId:folder.id,path:folder.name});
}
// Status line: always "found N files", never "found all". Unreadable folders
// are listed with their reason; tab scans add their visible-only caveat.
function buildScanMessage(result={}){
  const files=[...folderItems.values()].filter(i=>i.type!=='folder');
  const selectedFiles=files.filter(i=>i.selected).length;
  let text=t('138',files.length,selectedFiles?t('139',selectedFiles):'');
  if(result.cancelled||scanCancelled)text=t('140')+' '+text;
  if(result.truncated)text+=' '+t('141');
  if(result.source==='tab')text+=' '+t('142');
  if(folderUnreadable.length)text+=' '+t('143',folderUnreadable.map(u=>`${u.name} (${message(u.reason)})`).join(' · '));
  if(!files.length&&!folderUnreadable.length)text+=' '+t('64');
  return text;
}
// action() returns the scan payload; merging/message happen here only if this
// scan is still current, so a replaced/cancelled scan cannot clobber a newer one.
async function scan(action) {
  if(folderBusy)return;folderBusy=true;scanCancelled=false;
  const token=++scanToken;
  ensureCancelButton();if(cancelScanBtn)cancelScanBtn.disabled=false;
  $('scan-folder').disabled=true;$('scan-tab').disabled=true;$('import-folder').disabled=true;$('close-folder').disabled=true;
  renderFolder();
  setFolderMessage(t('63'));
  try {
    const result=await action();
    if(token!==scanToken)return;
    applyScanResult(result);
    setFolderMessage(buildScanMessage(result||{}));
  }
  catch(e){if(token===scanToken)setFolderMessage(e.message);}
  finally{
    if(token!==scanToken)return;
    folderBusy=false;if(cancelScanBtn)cancelScanBtn.disabled=true;
    $('scan-folder').disabled=false;$('scan-tab').disabled=false;$('close-folder').disabled=false;
    renderFolder();await saveFolder();
  }
}
bind('scan-folder',()=>scan(async()=>{
  const result=await send('scanFolder',{url:folder.url,name:folder.name,baseDepth:0,basePath:folder.name});
  return {...result,source:'folder'};
}));
bind('scan-tab',()=>scan(async()=>{
  const {items}=await send('scanTab',{url:folder.url});
  return {items,source:'tab',mergeOpts:{depth:1,parent:folder.name,parentId:folder.id,path:folder.name}};
}));
// Supplementary / retry scan for one subfolder: embedded recursive scan, or
// the tab scan when that subfolder is open in a Drive tab.
async function scanSubfolder(entry, useTab){
  if(folderBusy)return;
  await scan(async()=>{
    if(useTab){
      const {items}=await send('scanTab',{url:entry.url});
      return {items,source:'tab',mergeOpts:{depth:(entry.depth||1)+1,parent:entry.name,parentId:entry.id,path:entry.path||entry.name}};
    }
    const result=await send('scanFolder',{url:entry.url,name:entry.name,baseDepth:entry.depth||1,basePath:entry.path||entry.name});
    return {...result,source:'folder'};
  });
}
bind('open-folder',()=>send('open',{url:folder.url}));
bind('whole-folder',async()=>{
  if(zipBusy||!folder)return;
  const target=folder.url;zipBusy=true;pauseIdle('zip');$('whole-folder').disabled=true;setFolderMessage(t('171'));
  try{const result=await send('folderZip',{url:target});if(folder?.url===target)setFolderMessage(t(result?.ok?'65':'170'));}
  catch{if(folder?.url===target)setFolderMessage(t('170'));}
  finally{zipBusy=false;$('whole-folder').disabled=false;resumeIdle('zip');await saveFolder();}
});
$('folder-dialog').addEventListener('close',()=>resumeIdle('folder'));
function closeFolder(){folder=null;$('folder-dialog').close();saveFolder();}
bind('close-folder',()=>{if(!folderBusy)closeFolder();});
$('folder-dialog').addEventListener('cancel',event=>{if(folderBusy)event.preventDefault();else {folder=null;saveFolder();}});
bind('folder-all',()=>{for(const item of folderItems.values())if(item.type!=='folder')item.selected=$('folder-all').checked;renderFolder();saveFolder();});
bind('import-folder',async()=>{batch=await send('add',{items:[...folderItems.values()].filter(i=>i.selected&&i.type!=='folder')});render();closeFolder();});
if(globalThis.chrome?.runtime?.id) {
  if(new URLSearchParams(location.search).get('overlay')==='1') {
    $('hide-tool').hidden=false;
    bind('hide-tool',()=>send('hidePanel'));
    idleController=installIdleHide(window,document,()=>send('hidePanel'),error);
  }
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.batch){batch=changes.batch.newValue;render();}});
  refresh().catch(error);
  if(local)local.get(['linkDraft','folderDraft']).then(saved=>{
    if(!$('links').value&&typeof saved.linkDraft==='string')$('links').value=saved.linkDraft;
    if(saved.folderDraft&&!folder){
      folder=saved.folderDraft.folder;folderItems=new Map(saved.folderDraft.items.map(item=>[item.id,item]));
      folderUnreadable=Array.isArray(saved.folderDraft.unreadable)?saved.folderDraft.unreadable:[];
      $('folder-name').textContent=folder.name===folder.id?t('38'):folder.name;
      setFolderMessage(saved.folderDraft.message||t('66'));
      renderFolder();$('folder-dialog').showModal();pauseIdle('folder');
    } else if(!folder)$('links').focus();
  }).catch(error);
} else {
  render();
  for(const control of document.querySelectorAll('button,input,textarea'))if(!control.closest('#language-panel')&&!control.closest('#coffee-dialog')&&control.id!=='language-toggle'&&control.id!=='coffee-button')control.disabled=true;
  setAppMessage('Đây là giao diện tiện ích Chrome. Hãy cài thư mục này bằng Load unpacked tại chrome://extensions, sau đó mở từ biểu tượng Drive Batch. Trang web thông thường chỉ xem được giao diện.');
}

// HOA 0.5.3 — coffee dialog: opens ONLY on button click, never on load,
// never gates downloads, and pauses idle-hide while open (resume on close).
const COFFEE_ADDRESS='TYHoRN7Mhuu22wyTqb2x5GiG7yYEaQ2L6V';
let coffeeCopiedOk=null;
function openCoffee(){
  $('coffee-copied').hidden=true;$('coffee-copied').textContent='';coffeeCopiedOk=null;
  $('coffee-dialog').showModal();pauseIdle('coffee');
}
bind('coffee-button',()=>openCoffee());
bind('close-coffee',()=>$('coffee-dialog').close());
$('coffee-dialog').addEventListener('close',()=>{$('coffee-copied').hidden=true;coffeeCopiedOk=null;resumeIdle('coffee');});
bind('coffee-copy',async()=>{
  const notice=$('coffee-copied');
  try{await navigator.clipboard.writeText(COFFEE_ADDRESS);coffeeCopiedOk=true;}
  catch{
    try{
      const ta=document.createElement('textarea');ta.value=COFFEE_ADDRESS;ta.style.position='fixed';ta.style.opacity='0';
      document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();
      if(!ok)throw new Error('copy failed');coffeeCopiedOk=true;
    }catch{coffeeCopiedOk=false;}
  }
  notice.textContent=coffeeCopiedOk?t('167'):t('168');notice.hidden=false;
});

installLanguageMenu({pause:()=>pauseIdle('language'),resume:()=>resumeIdle('language'),onError:error});
onLanguageChange(()=>{
  render();renderFolder();renderInputResult();setAppMessage(appMessage);setFolderMessage(folderMessage);
  if(cancelScanBtn)cancelScanBtn.textContent=t('132');
  if(coffeeCopiedOk!==null&&!$('coffee-copied').hidden)$('coffee-copied').textContent=coffeeCopiedOk?t('167'):t('168');
  if(folder)$('folder-name').textContent=folder.name===folder.id?t('38'):folder.name;
});
