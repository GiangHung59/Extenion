import {createFolderZipLauncher} from './folder-zip.js';
import {parseLink, viewURL, downloadURL, prefixedName, parseFolderEntries, applyRename, applyInspectName, customDisplayName, deriveExt, exportExt, splitName} from './core.js';
import {request, readLimited, resolveDownload} from './network.js';
import {installToolPanel, hideToolPanel} from './tool-panel.js';

installToolPanel(chrome);
const launchFolderZip=createFolderZipLauncher(chrome);

const initial = {items:[], paused:true};
let state;
let chain = Promise.resolve();
let pumping = false;
const loaded = chrome.storage.local.get('batch').then(async ({batch}) => {
  state = batch || initial;
  // A worker can stop while probing or between creating and recording a download.
  // Never automatically restart an uncertain download: avoid duplicate files.
  for (const item of state.items) if (item.status === 'preparing') {
    item.status = 'action';item.message = 'Kiểm tra bị gián đoạn. Xem danh sách tải Chrome trước khi thử lại.';
  }
  await chrome.storage.local.set({batch:state});
});
function change(fn) {
  const task = chain.then(async () => {await loaded;const value = fn(state);await chrome.storage.local.set({batch:state});return value;});
  chain = task.catch(() => {});
  return task;
}
async function snapshot() {await loaded;await chain;return structuredClone(state);}
async function update(id, fields) {return change(s => {const item=s.items.find(i=>i.id===id);if(item)Object.assign(item,fields);});}

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function inspect(item) {
  let actual={...item};
  // A /file/d link can refer to a Workspace document. Resolve the official page first.
  if(item.type==='file') {
    try {
      const preview=await request(item.url,'include');
      let detected;
      try {detected=parseLink(preview.finalUrl);}catch{}
      if(detected?.id===item.id && detected.type!=='file') actual={...actual,type:detected.type};
      if(actual.type==='file' && preview.body) {
        const match=preview.body.match(/https:\/\/docs\.google\.com\/(document|spreadsheets|presentation)\/d\/([\w-]+)/);
        if(match?.[2]===item.id)actual.type=match[1];
      }
    }catch{/* The download endpoint still provides a useful independent check. */}
  }
  if(actual.type==='folder')return {status:'action',type:'folder',message:'Đây là thư mục. Quét và chọn các file bên trong.'};
  const url=downloadURL(actual);
  let result;
  // Chrome Downloads uses the browser session. Resolve large-file confirmation
  // with that same session instead of handing it an anonymous confirmation URL.
  // DIAGNOSTIC 0.5.3.2: keep the anonymous probe's result (including a Google
  // HTTP 500) instead of discarding it when the session probe throws. A 500
  // from Google is a server-side failure for that file/endpoint, not a sharing
  // verdict, and it is often transient, so retry it once before giving up.
  let access='session';
  let fetchError='';
  let omitNote='';
  if(item.mode==='download') {
    try {result=await resolveDownload(url,'include',actual);}
    catch(e) {fetchError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;result={status:'error'};}
    if(result.httpStatus===500) {
      await sleep(1500);
      try {const retry=await resolveDownload(url,'include',actual);if(retry.status==='ready')result=retry;}
      catch(e) {fetchError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;result={status:'error'};}
    }
  } else {
    let omitError='';
    try {result=await resolveDownload(url,'omit',actual);} catch(e) {omitError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;result={status:'error'};}
    if(result.httpStatus===500) {
      omitNote='Google HTTP 500 (lượt không cookie)';
      await sleep(1500);
      try {const retry=await resolveDownload(url,'omit',actual);if(retry.status==='ready')result=retry;else omitNote+=` rồi vẫn HTTP ${retry.httpStatus||'lỗi'} khi thử lại`;}
      catch(e) {omitError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;}
    } else if(result.status!=='ready'&&result.message) omitNote=result.message;
    access='public';
    if(result.status!=='ready') {
      try {result=await resolveDownload(url,'include',actual);access='session';}
      catch(e) {fetchError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;if(omitError)fetchError+=` (lượt không cookie cũng lỗi: ${omitError})`;else if(omitNote)fetchError+=` (lượt không cookie: ${omitNote})`;result={status:'error'};}
      if(!fetchError&&result.httpStatus===500) {
        await sleep(1500);
        try {const retry=await resolveDownload(url,'include',actual);if(retry.status==='ready')result=retry;}
        catch(e) {fetchError=`${e.name||'Error'}: ${e.message||'Failed to fetch'}`;if(omitNote)fetchError+=` (lượt không cookie: ${omitNote})`;result={status:'error'};}
      }
    }
  }
  if(fetchError) return {status:'error',type:actual.type,
    message:`Không gọi được Google từ tiện ích (${fetchError}). Đây chưa phải kết luận về quyền thư mục. Riêng HTTP 500 là lỗi phía máy chủ Google cho file/endpoint đó (thường thoáng qua hoặc do dạng file), không phải do thư mục chưa chia sẻ; nếu mở file trên Drive vẫn xem/tải được thì phần còn lại nằm ở đường gọi mạng của extension.`,
    access:'unknown', downloadUrl:url, confirmed:false};
  return {status:result.status,type:actual.type,
    ...(result.name ? {name:result.name.trim()} : {}),
    message:result.status==='ready' ? (access==='public'?'Tải được không cần đăng nhập':'Tải được với phiên Google hiện tại') : result.message,
    access:result.status==='ready'?access:'unknown', downloadUrl:result.downloadUrl||url, confirmed:!!result.confirmed};
}

async function reconcile() {
  const current=await snapshot();
  for(const item of current.items.filter(i=>i.status==='downloading' && Number.isInteger(i.downloadId))) {
    const [download]=await chrome.downloads.search({id:item.downloadId});
    if(!download) {await update(item.id,{status:'action',message:'Không còn thông tin lượt tải trong Chrome. Kiểm tra trước khi thử lại.'});continue;}
    const suspicious=/text\/html|application\/xhtml/i.test(download.mime) && !/\.html?$/i.test(item.name);
    if(suspicious) {
      if(download.state==='in_progress')await chrome.downloads.cancel(download.id).catch(()=>{});
      // Remove only the file generated by this extension's tracked download.
      if(download.state==='complete')await chrome.downloads.removeFile(download.id).catch(()=>{});
      await change(s=>{
        const latest=s.items.find(i=>i.id===item.id);
        if(!latest||latest.status!=='downloading'||latest.downloadId!==download.id)return;
        if((latest.htmlRetries||0)<1) {
          latest.htmlRetries=(latest.htmlRetries||0)+1;
          latest.status='queued';latest.mode='download';delete latest.downloadId;delete latest.downloadFilename;
          latest.message='Google trả trang xác nhận. Đang lấy lại đường tải file…';
        } else {
          latest.status='action';latest.message='Google vẫn trả HTML sau khi xác nhận lại. Mở Google để kiểm tra đăng nhập, quyền tải hoặc giới hạn lượt tải rồi thử lại.';
        }
      });
    } else if(download.state==='complete')await update(item.id,{status:'done',message:'Đã tải xong',filename:download.filename});
    else if(download.state==='interrupted')await update(item.id,{status:'error',message:`Tải bị ngắt: ${download.error || 'không rõ nguyên nhân'}`});
  }
}
async function pump() {
  if(pumping)return;pumping=true;
  try {
    await reconcile();
    while(true) {
      const current=await snapshot();
      if(current.paused || current.items.filter(i=>i.status==='downloading').length>=2)break;
      const item=current.items.find(i=>i.status==='queued');if(!item)break;
      await update(item.id,{status:'preparing',message:'Đang kiểm tra khả năng tải…'});
      try {
        const info=await inspect(item);
        // Re-check refreshes actualName but never overwrites a custom base.
        const latest=(await snapshot()).items.find(i=>i.id===item.id);
        const merged={...info,...applyInspectName(latest||item,info)};
        if(!(latest?.customBase)&&!merged.name&&latest?.name)merged.name=latest.name;
        await update(item.id,merged);
        if(info.status!=='ready' || item.mode==='check' || (await snapshot()).paused)continue;
        await update(item.id,{status:'preparing',message:'Đang bắt đầu tải…'});
        // Reserve the single save dialog for this click, persisted across worker restarts.
        const saveAs=await change(s=>{
          const latest=s.items.find(i=>i.id===item.id);
          const first=!!latest?.downloadRun&&!latest.promptUsed;
          if(first)for(const sibling of s.items)if(sibling.downloadRun===latest.downloadRun)sibling.promptUsed=true;
          return first;
        });
        const options={url:info.downloadUrl,saveAs,conflictAction:'uniquify'};
        // Supply a known final name before Chrome opens the save dialog. The
        // filename event can arrive before the download ID has been recorded.
        const naming=(await snapshot()).items.find(i=>i.id===item.id);
        const realName=[naming?.actualName,naming?.originalName,
          !naming?.customBase?naming?.name:null].find(name=>typeof name==='string'&&name.trim()&&name!==item.id);
        const original=realName&&(!splitName(realName).ext&&exportExt(naming.type)?realName+exportExt(naming.type):realName);
        const custom=naming?.customBase&&(original||naming.customExt||deriveExt(naming))?customDisplayName(naming,original):null;
        const prefix=naming?.downloadPrefix??naming?.prefix??'';
        const target=custom||original;
        const downloadFilename=target&&(custom||prefix.trim())?prefixedName(prefix,target):null;
        await update(item.id,{downloadFilename});
        if(downloadFilename)options.filename=downloadFilename;
        const id=await chrome.downloads.download(options);
        await update(item.id,{status:'downloading',downloadId:id,message:'Đang tải bằng Chrome…'});
        await reconcile();
      }catch(e) {
        if(/USER_CANCEL(?:ED|LED)|Download cancel(?:ed|led)/i.test(e.message||'')) {
          await change(s=>{for(const sibling of s.items)if(sibling.downloadRun===item.downloadRun&&['queued','preparing'].includes(sibling.status)){sibling.status='new';sibling.message='Đã hủy lưu. Bấm tải để bắt đầu lượt mới.';}});
        } else await update(item.id,{status:'error',message:e.name==='AbortError'?'Google phản hồi quá chậm. Hãy thử lại.':e instanceof TypeError?`Không gọi được Google từ tiện ích (${e.name}: ${e.message||'Failed to fetch'}). Mở file trên Drive để đối chiếu: nếu mở được thì không phải do quyền thư mục, mà do đường gọi mạng của extension.`:`Không tải được: ${e.message}`});
      }
    }
  }finally {pumping=false;}
}

chrome.alarms.create('batch-tick',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(()=>{pump().catch(console.error);});
chrome.downloads.onChanged.addListener(()=>{pump().catch(console.error);});
// Use Chrome's actual filename, including the export extension, even when Google's
// probe response did not provide a Content-Disposition filename.
chrome.downloads.onDeterminingFilename.addListener((download,suggest)=>{
  if(download.byExtensionId!==chrome.runtime.id){suggest();return;}
  snapshot().then(current=>{
    const item=current.items.find(i=>i.downloadId===download.id&&i.status==='downloading') ||
      current.items.find(i=>i.status==='preparing'&&i.downloadUrl===download.url);
    if(item?.downloadFilename){suggest({filename:item.downloadFilename,conflictAction:'uniquify'});return;}
    const prefix=item?.downloadPrefix??item?.prefix??'';
    const original=download.filename.split(/[\\/]/).pop();
    // A custom name must win even with an empty prefix, otherwise Chrome
    // would silently download under the original name and ignore the rename.
    const custom=item?customDisplayName(item,original):null;
    if(!custom&&!prefix.trim()){suggest();return;}
    suggest({filename:prefixedName(prefix,custom||original),conflictAction:'uniquify'});
  },()=>suggest());
  return true;
});
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('')))return;
  handle(message,sender).then(respond,e=>respond({error:e.message}));return true;
});
async function handle(message,sender={}) {
  if(message.type==='hidePanel') {
    if(!Number.isInteger(sender.tab?.id)||new URL(sender.url).searchParams.get('overlay')!=='1')throw new Error('Không xác định được tab của công cụ.');
    await hideToolPanel(chrome,sender.tab.id);return {ok:true};
  }
  if(message.type==='get') {await reconcile();return snapshot();}
  if(message.type==='add') {
    await change(s=>{for(const input of message.items){const item=parseLink(input.url);if(!s.items.some(i=>i.id===item.id)){
      const name=typeof input.name==='string'?input.name.slice(0,500):item.name;
      // A folder listing already knows the real name (unlike a bare link,
      // whose name is just the ID until the first check). Record it so a
      // later custom-name restore has a real original to return to.
      const realName=name!==item.id?name:'';
      s.items.push({...item,name,parent:input.parent||'',...(realName?{originalName:realName,actualName:realName}:{})});
    }}});
    return snapshot();
  }
  if(message.type==='rename') {
    // Lock: queued/preparing/downloading items keep their queued name.
    // Empty base is rejected and never stored; {clear:true} restores the
    // real name. See core.applyRename for the shared rules.
    await change(s=>{
      const item=s.items.find(i=>i.id===message.id);
      if(!item)throw new Error('Không tìm thấy file.');
      const fields=applyRename(item,message);
      if(fields.clearCustom){delete item.customBase;delete item.customExt;item.name=item.actualName||item.originalName||item.name;}
      else Object.assign(item,fields,{name:fields.customBase+(fields.customExt||'')});
    });
    return snapshot();
  }
  if(message.type==='select') {await change(s=>{for(const i of s.items)if(message.ids.includes(i.id)&&i.type!=='folder')i.selected=message.selected;});return snapshot();}
  if(message.type==='prefix') {
    await change(s=>{
      const item=s.items.find(i=>i.id===message.id);
      if(item&&item.type!=='folder'&&!['queued','preparing','downloading'].includes(item.status))item.prefix=typeof message.prefix==='string'?message.prefix.slice(0,100):'';
    });
    return {ok:true};
  }
  if(message.type==='queue') {
    const downloadRun=crypto.randomUUID();
    await change(s=>{s.paused=false;for(const i of s.items)if(message.ids.includes(i.id)&&i.type!=='folder'&&!['preparing','downloading','queued','done'].includes(i.status)){
      i.status='queued';i.mode=message.mode==='check'?'check':'download';i.message='Đang chờ';
      i.downloadRun=i.mode==='download'?downloadRun:null;i.promptUsed=false;
      if(i.mode==='download') {
        i.htmlRetries=0;
        if(typeof message.prefixes?.[i.id]==='string')i.prefix=message.prefixes[i.id].slice(0,100);
        i.downloadPrefix=i.prefix||'';
        // Fill a still-unknown custom extension from the latest real name
        // before downloading; onDeterminingFilename still falls back to
        // Chrome's actual filename extension as a last resort.
        if(i.customBase&&!i.customExt){const ext=deriveExt(i);if(ext)i.customExt=ext;}
      }
      delete i.downloadId;delete i.downloadFilename;
    }});
    void pump();return snapshot();
  }
  if(message.type==='stop') {await change(s=>{s.paused=true;for(const i of s.items)if(i.status==='queued'){i.status='new';i.message='Đã dừng hàng đợi';}});return snapshot();}
  if(message.type==='clear') {await change(s=>{s.items=s.items.filter(i=>['preparing','downloading','queued'].includes(i.status));});return snapshot();}
  if(message.type==='folderZip') {
    const item=parseLink(message.url);if(item.type!=='folder')throw new Error('Không phải thư mục.');
    return launchFolderZip(item);
  }
  if(message.type==='open') {
    const item=parseLink(message.url);await chrome.tabs.create({url:item.url});return {ok:true};
  }
  if(message.type==='scanFolder') {
    const root=parseLink(message.url);if(root.type!=='folder')throw new Error('Không phải thư mục.');
    if(typeof message.name==='string'&&message.name.trim())root.name=message.name.trim().slice(0,500);
    // A new scan replaces any running one; the replaced scan returns its
    // partial result with cancelled:true instead of throwing.
    if(activeScan)activeScan.controller.abort();
    const controller=new AbortController();activeScan={controller};
    // baseDepth/basePath let a subfolder re-scan merge at absolute depth/path.
    const baseDepth=Number.isInteger(message.baseDepth)?message.baseDepth:0;
    const basePath=typeof message.basePath==='string'&&message.basePath?message.basePath:root.name;
    try {return await scanFolderRecursive(root,controller.signal,{baseDepth,basePath});}
    finally {if(activeScan?.controller===controller)activeScan=null;}
  }
  if(message.type==='cancelScan') {
    if(activeScan)activeScan.controller.abort();
    return {ok:true,cancelled:true};
  }
  if(message.type==='folderHTML') {
    const item=parseLink(message.url);if(item.type!=='folder')throw new Error('Không phải thư mục.');
    const url=new URL('https://drive.google.com/embeddedfolderview');url.searchParams.set('id',item.id);
    if(item.resourceKey)url.searchParams.set('resourcekey',item.resourceKey);
    if(item.authuser)url.searchParams.set('authuser',item.authuser);
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),20000);
    try {const r=await fetch(url,{credentials:'include',signal:controller.signal});if(!r.ok)throw new Error(`Google trả HTTP ${r.status}. Mở thư mục trên Drive để kiểm tra quyền.`);return {html:await readLimited(r,2000000)};}
    finally {clearTimeout(timer);}
  }
  if(message.type==='scanTab') {
    const folder=parseLink(message.url);if(folder.type!=='folder')throw new Error('Không phải thư mục.');
    return {items:await readVisibleFolder(folder)};
  }
  throw new Error('Lệnh không hợp lệ.');
}

// Read only an already-open matching Drive tab; never open or navigate a tab.
async function readVisibleFolder(folder){
  const tabs=await chrome.tabs.query({url:'https://drive.google.com/*'});
  const candidates=tabs.filter(tab=>{try{const item=parseLink(tab.url);return item.type==='folder'&&item.id===folder.id&&(!folder.authuser||item.authuser===folder.authuser||(!item.authuser&&folder.authuser==='0'));}catch{return false;}});
  const tab=candidates.find(t=>t.active)||candidates[0];
  if(!tab)throw new Error('Hãy mở thư mục trên Drive, chờ danh sách hiện ra rồi bấm “Quét tab Drive”.');
  const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:collectVisibleDriveItems});
  const account=folder.authuser||parseLink(tab.url).authuser;
  return (results[0]?.result||[]).flatMap(entry=>{try{const item=parseLink(entry.url);if(!item.authuser)item.authuser=account;return [{...entry,url:viewURL(item)}];}catch{return [];}});
}
function validFolderEntries(entries,current){
  return entries.filter(entry=>{try{const item=parseLink(entry.url);return item.id!==current.id;}catch{return false;}});
}

// --- Recursive folder scan (TRÀ, 0.5.3) ---------------------------------
// Breadth-first over embeddedfolderview pages. No Google API, no OAuth.
// Bounded (depth/folder/file caps) so one huge tree cannot hammer Google.
// visited-set stops loops (a folder linked twice, or back into an ancestor);
// cancellation aborts the in-flight fetch and returns partial results.
// Completeness is NEVER claimed: folders that fail, return nothing, or are
// cut off by a cap are reported in `unreadable`, and the panel must say
// "found N files", never "found all".
const MAX_SCAN_DEPTH=10, MAX_SCAN_FOLDERS=100, MAX_SCAN_FILES=2000;
let activeScan=null;
function embeddedFolderURL(item){
  const url=new URL('https://drive.google.com/embeddedfolderview');url.searchParams.set('id',item.id);
  if(item.resourceKey)url.searchParams.set('resourcekey',item.resourceKey);
  if(item.authuser)url.searchParams.set('authuser',item.authuser);
  return url.href;
}
async function fetchFolderPage(item, signal){
  const controller=new AbortController();
  const onAbort=()=>controller.abort();
  signal.addEventListener('abort',onAbort,{once:true});
  const timer=setTimeout(()=>controller.abort(),20000);
  try {
    const r=await fetch(embeddedFolderURL(item),{credentials:'include',signal:controller.signal});
    if(!r.ok)throw new Error(`Google trả HTTP ${r.status}. Mở thư mục trên Drive để kiểm tra quyền.`);
    return await readLimited(r,2000000);
  } finally {clearTimeout(timer);signal.removeEventListener('abort',onAbort);}
}
async function scanFolderRecursive(root, signal, opts={}){
  const entries=[], unreadable=[], folderStates=[];
  const visited=new Set([root.id]), seenFiles=new Set();
  const queue=[{...root,depth:opts.baseDepth||0,path:opts.basePath||root.name||root.id}];
  let scannedFolders=0, fileCount=0, truncated=false;
  const markTruncated=()=>{if(!truncated){truncated=true;}};
  while(queue.length){
    if(signal.aborted)break;
    const current=queue.shift();
    if(scannedFolders>=MAX_SCAN_FOLDERS){
      markTruncated();
      unreadable.push({id:current.id,name:current.name,url:current.url,reason:'Đã dừng quét thư mục này vì vượt giới hạn 100 thư mục.'});
      folderStates.push({id:current.id,ok:false,reason:'Vượt giới hạn 100 thư mục.'});
      continue;
    }
    scannedFolders++;
    let raw=[],reason='';
    try {raw=validFolderEntries(parseFolderEntries(await fetchFolderPage(current,signal)),current);}
    catch(e){
      if(signal.aborted)break;
      reason=e.name==='AbortError'?'Quét quá chậm (hết 20 giây).':e.message;
    }
    if(signal.aborted)break;
    // Embedded pages can omit entries for a signed-in account. Reuse visible
    // rows from an existing tab before concluding that nothing was readable.
    if(!raw.length){
      try{raw=validFolderEntries(await readVisibleFolder(current),current);}catch{}
    }
    if(signal.aborted)break;
    if(!raw.length){
      reason=reason||'Không đọc được mục nào — có thể thư mục trống, thiếu quyền, hoặc Google không hiển thị danh sách.';
      unreadable.push({id:current.id,name:current.name,url:current.url,reason});
      folderStates.push({id:current.id,ok:false,reason});
      continue;
    }
    folderStates.push({id:current.id,ok:true});
    for(const entry of raw){
      if(signal.aborted)break;
      let item;try{item=parseLink(entry.url);if(!item.authuser)item.authuser=current.authuser;item.url=viewURL(item);}catch{continue;}
      if(item.id===root.id)continue;
      const name=(entry.name||'').slice(0,500)||item.id;
      const path=`${current.path} › ${name}`;
      const depth=current.depth+1;
      if(item.type==='folder'){
        entries.push({url:item.url,name,type:'folder',parent:current.name,parentId:current.id,depth,path,scanState:'pending'});
        if(!visited.has(item.id)){
          visited.add(item.id);
          if(depth<MAX_SCAN_DEPTH)queue.push({...item,name,depth,path});
          else {
            markTruncated();
            unreadable.push({id:item.id,name,url:item.url,reason:'Chưa quét thư mục con này vì vượt độ sâu tối đa 10.'});
            folderStates.push({id:item.id,ok:false,reason:'Vượt độ sâu tối đa 10.'});
          }
        }
      } else {
        if(seenFiles.has(item.id))continue;
        seenFiles.add(item.id);
        if(fileCount>=MAX_SCAN_FILES){markTruncated();continue;}
        fileCount++;
        entries.push({url:item.url,name,type:item.type,parent:current.name,parentId:current.id,depth,path});
      }
    }
  }
  return {entries,unreadable,folderStates,cancelled:signal.aborted,truncated};
}

// Reads only currently rendered entries. No guessed completeness, no hidden API tokens.
function collectVisibleDriveItems() {
  const found=new Map();
  for(const el of document.querySelectorAll('[data-id]')) {
    const id=el.getAttribute('data-id');
    if(!/^[\w-]{10,}$/.test(id)||!el.getClientRects().length)continue;
    if(!el.matches('[role="row"], [role="gridcell"], [role="listitem"]')&&!el.querySelector('[role="gridcell"]'))continue;
    const img=el.querySelector('img');
    const hints=[el.getAttribute('data-mime-type'),img?.src,img?.alt].filter(Boolean).join(' ');
    let type='file';
    if(/folder|thư mục/i.test(hints))type='folder';
    else if(/vnd.google-apps.document|Google Docs|Google Tài liệu/i.test(hints))type='document';
    else if(/vnd.google-apps.spreadsheet|Google Sheets|Google Trang tính/i.test(hints))type='spreadsheets';
    else if(/vnd.google-apps.presentation|Google Slides|Google Trang trình bày/i.test(hints))type='presentation';
    const name=el.querySelector('[data-tooltip]')?.getAttribute('data-tooltip')||el.querySelector('[data-column-field="name"]')?.textContent||el.getAttribute('aria-label')||id;
    const url=type==='folder'?`https://drive.google.com/drive/folders/${id}`:type==='file'?`https://drive.google.com/file/d/${id}/view`:`https://docs.google.com/${type}/d/${id}/edit`;
    found.set(id,{url,name:name.trim()});
  }
  return [...found.values()];
}
