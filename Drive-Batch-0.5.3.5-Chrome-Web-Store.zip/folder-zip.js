// Native Drive UI adapter. Verified against the folder breadcrumb menu on
// 2026-10-29; selectors failing to match must fail closed, never select children.
export async function requestNativeFolderZip(folderId) {
  const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const visible=e=>e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
  const correctPage=()=>location.hostname==='drive.google.com'&&location.pathname.match(/\/folders\/([\w-]+)/)?.[1]===folderId;
  const menus=()=>[...document.querySelectorAll('[role="menu"]')].filter(visible);
  if(!correctPage())return {ok:false,reason:'wrong-page'};
  const prior=new Set(menus());let control;
  for(let n=0;n<60;n++){
    if(!correctPage())return {ok:false,reason:'navigated'};
    const controls=[...document.querySelectorAll('[guidedhelpid="folder_path_button"] [role="button"][aria-haspopup]')].filter(visible);
    if(controls.length===1){control=controls[0];break;}
    await sleep(250);
  }
  if(!control||control.getAttribute('aria-disabled')==='true')return {ok:false,reason:'folder-menu-unavailable'};
  // Closure breadcrumb handles ArrowDown even in a background tab; .click()
  // alone did not open this menu during the live verification.
  control.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',code:'ArrowDown',keyCode:40,which:40,bubbles:true,cancelable:true}));
  for(let n=0;n<40;n++){
    if(!correctPage())return {ok:false,reason:'navigated'};
    const opened=menus().filter(e=>!prior.has(e));
    // data-key=8 was observed on the native folder Download action. Scope it
    // only to the menu just opened from this folder, never global file menus.
    const actions=opened.flatMap(menu=>[...menu.querySelectorAll('[role="menuitem"][data-key="8"]')]).filter(e=>visible(e)&&e.getAttribute('aria-disabled')!=='true');
    if(actions.length>1)return {ok:false,reason:'ambiguous-menu'};
    if(actions.length===1){actions[0].click();return {ok:true,state:'requested'};}
    await sleep(250);
  }
  return {ok:false,reason:'download-unavailable'};
}
export function createFolderZipLauncher(chrome) {
  const pending=new Map();
  return function launch(item){
    const key=JSON.stringify([item.id,item.authuser||'',item.resourceKey||'']);
    if(pending.has(key))return pending.get(key);
    const job=(async()=>{
      // Persist accepted requests so reopening the panel/worker does not send
      // duplicate ZIP jobs. A later deliberate retry is allowed after 60 sec.
      const saved=(await chrome.storage.local.get('folderZipRequests')).folderZipRequests||{};
      if(Date.now()-(saved[key]||0)<60000)return {ok:true,state:'already-requested'};
      const tab=await chrome.tabs.create({url:item.url,active:false});
      const deadline=Date.now()+30000;
      while(Date.now()<deadline){
        const current=await chrome.tabs.get(tab.id);
        const url=new URL(current.url||item.url);
        if(url.hostname!=='drive.google.com')return {ok:false,reason:'login-required',tabId:tab.id};
        if(current.status==='complete'){
          const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:requestNativeFolderZip,args:[item.id]});
          const result=results[0]?.result||{ok:false,reason:'no-response'};
          if(result.ok){
            try {
              const latest=(await chrome.storage.local.get('folderZipRequests')).folderZipRequests||{};
              const now=Date.now();const recent=Object.fromEntries(Object.entries(latest).filter(([,time])=>now-time<60000));
              recent[key]=now;await chrome.storage.local.set({folderZipRequests:recent});
            } catch {
              // Drive already accepted the click. A cooldown persistence error
              // must not report a failed request and invite a duplicate retry.
              return {...result,tabId:tab.id,warning:'cooldown-not-saved'};
            }
          }
          return {...result,tabId:tab.id};
        }
        await new Promise(resolve=>setTimeout(resolve,250));
      }
      return {ok:false,reason:'timeout',tabId:tab.id};
    })().catch(()=>({ok:false,reason:'browser-error'})).finally(()=>pending.delete(key));
    pending.set(key,job);return job;
  };
}
