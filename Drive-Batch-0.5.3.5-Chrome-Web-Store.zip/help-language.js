import {initLanguage,t,languageState,onLanguageChange} from './i18n.js';
await initLanguage();
const main=document.querySelector('main'),original=main.innerHTML;
const privacy=document.querySelector('a[href*="privacy.html"]'),support=document.querySelector('a[href^="mailto:"]');
const originalPrivacy=privacy.textContent,originalSupport=support.textContent;
function renderHelp(){
privacy.textContent=languageState().language==='vi'?originalPrivacy:'gianghung59.github.io/drive-batch/privacy.html';
support.textContent=languageState().language==='vi'?originalSupport:'gianghung1298@gmail.com';
if(languageState().language==='vi'){main.innerHTML=original;return;}
{
  main.replaceChildren();
  const title=document.createElement('h1');title.textContent=t('5');main.append(title);
  for(const [heading,keys] of [['7',['8','12','26','31','32']],['53',['39','47','65']],['19',['73','74','76','77','89']],['21',['61']],['106',['107']]]){
    const h=document.createElement('h2');h.textContent=t(heading);main.append(h);
    for(const key of keys){const p=document.createElement('p');p.textContent=t(key);main.append(p);}
  }
  const formats=document.createElement('p');formats.textContent='Google Docs → Word (.docx) · Google Sheets → Excel (.xlsx) · Google Slides → PowerPoint (.pptx)';main.append(formats);
  const back=document.createElement('a');back.href='index.html';back.textContent='← Drive Batch';main.append(back);
}
}
renderHelp();onLanguageChange(renderHelp);
