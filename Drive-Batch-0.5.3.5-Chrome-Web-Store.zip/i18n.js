import {LANGUAGES, resolveLanguage} from './languages.js';
let source={}, catalog={}, preference='auto', language='vi', revision=0;
const listeners=new Set(), edgeSpaces=new WeakMap();
let saveQueue=Promise.resolve(), writingPreference=null;
const clean=value=>String(value).replace(/\s+/g,' ').trim();
let keys=new Map();
const browserLanguages=()=>[globalThis.chrome?.i18n?.getUILanguage?.(),...(navigator.languages?.length?navigator.languages:[navigator.language])];
export const languageState=()=>({preference,language,info:LANGUAGES.find(l=>l.code===language),systemInfo:LANGUAGES.find(l=>l.code===resolveLanguage('auto',browserLanguages()))});
export function sourceText(key,...args){return String(source[key]??key).replace(/\{(\d+)\}/g,(all,i)=>String(args[i]??all));}
export function t(key,...args){return String(catalog[key]??source[key]??key).replace(/\{(\d+)\}/g,(all,i)=>String(args[i]??all));}
export function text(sourceText){const key=keys.get(clean(sourceText));return key===undefined?String(sourceText):t(key);}
export function message(value){
  const raw=String(value??'');
  const httpError=raw.match(/^Google tr\u1ea3 l\u1ed7i HTTP (\d+)\.$/);if(httpError)return `Google: HTTP ${httpError[1]}.`;
  const exact=keys.get(clean(raw));if(exact!==undefined)return t(exact);
  const patterns=[['119',/^Tìm thấy (.*) mục\. Chưa xác nhận đủ toàn bộ thư mục; chọn các mục muốn thêm bên dưới\.$/s],['120',/^Tải bị ngắt: (.*)$/s],['121',/^Không tải được: (.*)$/s],['122',/^Google trả HTTP (.*)\. Mở thư mục trên Drive để kiểm tra quyền\.$/s]];
  for(const [key,re] of patterns){const match=raw.match(re);if(match)return t(key,text(match[1]));}
  // Link validation errors contain the unchanged user's URL followed by our error.
  return raw.split('\n').map(line=>{for(const [original,key] of keys){if(line.endsWith(': '+original))return line.slice(0,-original.length)+t(key);}return line;}).join('\n');
}
export function applyTranslations(root=document){
  for(const el of root.querySelectorAll('[data-i18n]')){
    if(!edgeSpaces.has(el))edgeSpaces.set(el,[el.textContent.match(/^\s*/)[0],el.textContent.match(/\s*$/)[0]]);
    const [before,after]=edgeSpaces.get(el);el.textContent=before+t(el.dataset.i18n)+after;
  }
  for(const attr of ['aria-label','placeholder','title','alt'])for(const el of root.querySelectorAll(`[data-i18n-${attr}]`))el.setAttribute(attr,t(el.getAttribute(`data-i18n-${attr}`)));
  document.documentElement.lang=language;
  document.documentElement.dir=languageState().info?.dir||'ltr';
  document.title=t('0');
}
export function onLanguageChange(fn){listeners.add(fn);return()=>listeners.delete(fn);}
export async function setLanguage(next,{persist=true}={}){
  const ticket=++revision;
  const pref=next==='auto'||LANGUAGES.some(l=>l.code===next)?next:'auto';
  const resolved=resolveLanguage(pref,browserLanguages());
  const response=await fetch(new URL(`./locales/${resolved}.json`,import.meta.url));
  if(!response.ok)throw new Error(`Cannot load language: ${resolved}`);
  const nextCatalog=await response.json();
  if(ticket!==revision)return false;
  // Persist before presenting the new choice; a failed save does not look successful.
  if(persist){
    const save=saveQueue.then(async()=>{
      if(ticket!==revision)return;
      writingPreference=pref;
      try{await globalThis.chrome?.storage?.local?.set({languagePreference:pref});}
      finally{writingPreference=null;}
    });
    saveQueue=save.catch(()=>{});await save;
  }
  if(ticket!==revision)return false;
  preference=pref;language=resolved;catalog=nextCatalog;applyTranslations();
  for(const fn of listeners)fn(languageState());
  return true;
}
export async function initLanguage(){
  const response=await fetch(new URL('./locales/vi.json',import.meta.url));source=await response.json();
  keys=new Map(Object.entries(source).map(([key,value])=>[clean(value),key]));
  const saved=await globalThis.chrome?.storage?.local?.get('languagePreference');
  await setLanguage(saved?.languagePreference||'auto',{persist:false});
  window.addEventListener('languagechange',()=>{if(preference==='auto')setLanguage('auto',{persist:false}).catch(console.error);});
  globalThis.chrome?.storage?.onChanged?.addListener((changes,area)=>{
    if(area==='local'&&changes.languagePreference){const next=changes.languagePreference.newValue||'auto';if(next!==preference&&next!==writingPreference)setLanguage(next,{persist:false}).catch(console.error);}
  });
}
