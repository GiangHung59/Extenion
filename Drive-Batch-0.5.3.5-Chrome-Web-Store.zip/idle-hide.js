export function installIdleHide(target,activityTarget,hide,onError,timers=globalThis) {
  let timer,paused=false,disposed=false,generation=0;
  const cancel=()=>{
    generation++;
    timers.clearTimeout(timer);
    timer=undefined;
  };
  const reset=()=>{
    cancel();
    if(paused||disposed)return;
    const current=generation;
    timer=timers.setTimeout(()=>Promise.resolve().then(()=>{
      if(!paused&&!disposed&&current===generation)return hide();
    }).catch(onError),20000);
  };
  const events=['pointerdown','pointermove','keydown','input','wheel','touchstart'];
  const pause=()=>{paused=true;cancel();};
  const resume=()=>{if(disposed)return;paused=false;reset();};
  const dispose=()=>{
    if(disposed)return;
    disposed=true;
    cancel();
    for(const event of events)activityTarget.removeEventListener?.(event,reset);
    target.removeEventListener?.('focus',reset);
    target.removeEventListener?.('pagehide',dispose);
  };
  for(const event of events)activityTarget.addEventListener(event,reset,{passive:true});
  target.addEventListener('focus',reset);
  target.addEventListener('pagehide',dispose,{once:true});
  reset();
  return {pause,resume,dispose};
}
