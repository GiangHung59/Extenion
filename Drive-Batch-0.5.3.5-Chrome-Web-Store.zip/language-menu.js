import {LANGUAGES,searchLanguages} from './languages.js';
import {t,languageState,setLanguage,onLanguageChange} from './i18n.js';
export function installLanguageMenu({pause=()=>{},resume=()=>{},onError=console.error}={}){
  const trigger=document.getElementById('language-toggle'),panel=document.getElementById('language-panel');
  const search=document.getElementById('language-search'),list=document.getElementById('language-list');
  const auto=document.getElementById('language-auto');let busy=false;
  const isOpen=()=>panel.open;
  function position(){const box=trigger.getBoundingClientRect();panel.style.right=`${Math.max(8,innerWidth-box.right)}px`;panel.style.bottom=`${Math.max(8,innerHeight-box.top+8)}px`;panel.style.maxHeight=`${Math.max(120,box.top-16)}px`;}
  function close(){if(!isOpen())return;panel.close();trigger.setAttribute('aria-expanded','false');resume();trigger.focus({preventScroll:true});}
  async function select(code){
    if(busy)return;busy=true;panel.setAttribute('aria-busy','true');
    try{await setLanguage(code);close();}catch(e){onError(e);}finally{busy=false;panel.removeAttribute('aria-busy');}
  }
  function render(){
    const {preference,info,systemInfo}=languageState();
    document.getElementById('language-label').textContent=t('106');
    document.getElementById('language-choice').textContent=preference==='auto'?t('108'):info.name;
    trigger.title=preference==='auto'?`${t('107')} — ${info.name}`:info.name;
    document.getElementById('language-heading').textContent=t('106');
    search.placeholder=t('109');search.setAttribute('aria-label',t('109'));
    document.getElementById('language-auto-label').textContent=t('107');
    document.getElementById('language-current').textContent=t('110',systemInfo.name);
    auto.setAttribute('aria-selected',String(preference==='auto'));
    const results=searchLanguages(search.value);list.replaceChildren();
    for(const item of results){const row=document.createElement('button');row.type='button';row.className='language-option';row.setAttribute('role','option');row.dataset.code=item.code;row.setAttribute('aria-selected',String(preference===item.code));
      const name=document.createElement('bdi');name.textContent=item.name;name.lang=item.code;name.dir=item.dir;row.append(name);
      const check=document.createElement('span');check.textContent=preference===item.code?'✓':'';check.setAttribute('aria-hidden','true');row.append(check);
      row.addEventListener('click',()=>select(item.code));list.append(row);}
    const empty=document.getElementById('language-empty');empty.textContent=t('111');empty.hidden=results.length>0;
    document.getElementById('language-count').textContent=String(LANGUAGES.length);
    panel.dir=info.dir;
  }
  trigger.addEventListener('click',()=>{if(isOpen()){close();return;}search.value='';render();panel.show();position();trigger.setAttribute('aria-expanded','true');pause();search.focus();});
  auto.addEventListener('click',()=>select('auto'));search.addEventListener('input',render);
  panel.addEventListener('cancel',e=>{e.preventDefault();close();});
  panel.addEventListener('keydown',e=>{
    if(e.key==='Escape'){e.preventDefault();close();return;}
    if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;
    if(document.activeElement===search&&['Home','End'].includes(e.key))return;
    const options=[auto,...list.querySelectorAll('button')];let i=options.indexOf(document.activeElement);
    if(e.key==='ArrowDown')i=(i+1)%options.length;
    if(e.key==='ArrowUp')i=i<=0?options.length-1:i-1;
    if(e.key==='Home')i=0;if(e.key==='End')i=options.length-1;
    e.preventDefault();options[i]?.focus();
  });
  document.addEventListener('pointerdown',e=>{if(isOpen()&&!panel.contains(e.target)&&!trigger.contains(e.target))close();});
  document.addEventListener('focusin',e=>{if(isOpen()&&!panel.contains(e.target)&&!trigger.contains(e.target))close();});
  window.addEventListener('resize',()=>{if(isOpen())position();});
  onLanguageChange(()=>{render();if(isOpen())position();});render();
  return {close,isOpen};
}
