// Translation locale codes checked against https://cloud.google.com/translate/docs/languages.
// Only the 60 completed catalogs are selectable. Chinese has two writing systems.
// Regional variants otherwise share one entry.
export const LANGUAGES = Object.freeze([
  ['af', 'Afrikaans', 'Afrikaans'],
  ['sq', 'Shqip', 'Albanian'],
  ['ar', 'العربية', 'Arabic', 'rtl'],
  ['az', 'Azərbaycan', 'Azerbaijani'],
  ['eu', 'Euskara', 'Basque'],
  ['be', 'Беларуская', 'Belarusian'],
  ['bs', 'Bosanski', 'Bosnian'],
  ['bg', 'Български', 'Bulgarian'],
  ['ca', 'Català', 'Catalan'],
  ['ceb', 'Cebuano', 'Cebuano'],
  ['zh-CN', '简体中文', 'Chinese (Simplified)'],
  ['zh-TW', '繁體中文', 'Chinese (Traditional)'],
  ['hr', 'Hrvatski', 'Croatian'],
  ['cs', 'Čeština', 'Czech'],
  ['da', 'Dansk', 'Danish'],
  ['nl', 'Nederlands', 'Dutch'],
  ['en', 'English', 'English'],
  ['et', 'Eesti', 'Estonian'],
  ['tl', 'Filipino', 'Filipino'],
  ['fi', 'Suomi', 'Finnish'],
  ['fr', 'Français', 'French'],
  ['gl', 'Galego', 'Galician'],
  ['de', 'Deutsch', 'German'],
  ['el', 'Ελληνικά', 'Greek'],
  ['gu', 'ગુજરાતી', 'Gujarati'],
  ['ha', 'Hausa', 'Hausa'],
  ['he', 'עברית', 'Hebrew', 'rtl'],
  ['hi', 'हिन्दी', 'Hindi'],
  ['hu', 'Magyar', 'Hungarian'],
  ['id', 'Bahasa Indonesia', 'Indonesian'],
  ['it', 'Italiano', 'Italian'],
  ['ja', '日本語', 'Japanese'],
  ['kk', 'Қазақша', 'Kazakh'],
  ['ko', '한국어', 'Korean'],
  ['lv', 'Latviešu', 'Latvian'],
  ['lt', 'Lietuvių', 'Lithuanian'],
  ['mk', 'Македонски', 'Macedonian'],
  ['ms', 'Bahasa Melayu', 'Malay'],
  ['mn', 'Монгол', 'Mongolian'],
  ['no', 'Norsk', 'Norwegian'],
  ['fa', 'فارسی', 'Persian', 'rtl'],
  ['pl', 'Polski', 'Polish'],
  ['pt', 'Português', 'Portuguese'],
  ['ro', 'Română', 'Romanian'],
  ['ru', 'Русский', 'Russian'],
  ['sr', 'Српски', 'Serbian'],
  ['sk', 'Slovenčina', 'Slovak'],
  ['sl', 'Slovenščina', 'Slovenian'],
  ['so', 'Soomaali', 'Somali'],
  ['es', 'Español', 'Spanish'],
  ['su', 'Basa Sunda', 'Sundanese'],
  ['sw', 'Kiswahili', 'Swahili'],
  ['sv', 'Svenska', 'Swedish'],
  ['tg', 'Тоҷикӣ', 'Tajik'],
  ['tr', 'Türkçe', 'Turkish'],
  ['uk', 'Українська', 'Ukrainian'],
  ['ur', 'اردو', 'Urdu', 'rtl'],
  ['uz', 'Oʻzbek', 'Uzbek'],
  ['vi', 'Tiếng Việt', 'Vietnamese'],
  ['cy', 'Cymraeg', 'Welsh'],
].map(([code, name, english, dir = 'ltr']) => Object.freeze({code, name, english, dir})));

const byCode = new Map(LANGUAGES.map(language => [language.code.toLowerCase(), language.code]));
const aliases = {iw: 'he', in: 'id', jw: 'jv', fil: 'tl', nb: 'no', nn: 'no'};

function matchLanguage(value) {
  if (typeof value !== 'string') return undefined;
  const tag = value.trim().replaceAll('_', '-').toLowerCase();
  if (byCode.has(tag)) return byCode.get(tag);
  const [base, ...parts] = tag.split('-');
  if (base === 'zh') {
    // An explicit script takes priority over region (e.g. zh-Hans-HK).
    if (parts.includes('hant')) return 'zh-TW';
    if (parts.includes('hans')) return 'zh-CN';
    return parts.some(part => ['tw', 'hk', 'mo'].includes(part)) ? 'zh-TW' : 'zh-CN';
  }
  return byCode.get(aliases[base] || base);
}

/** Return a packaged locale code; unknown saved preferences use browser order. */
export function resolveLanguage(preference = 'auto', browserLanguages = globalThis.navigator?.languages || []) {
  const explicit = matchLanguage(preference);
  if (explicit) return explicit;
  const candidates = typeof browserLanguages === 'string' ? [browserLanguages] : browserLanguages;
  for (const candidate of Array.isArray(candidates) ? candidates : []) {
    const matched = matchLanguage(candidate);
    if (matched) return matched;
  }
  return 'en';
}

function normalizeSearch(value) {
  return String(value ?? '').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().trim();
}

/** Match native names, English names, or locale codes, ignoring accents/case. */
export function searchLanguages(query = '') {
  const words = normalizeSearch(query).split(/\s+/).filter(Boolean);
  return LANGUAGES.filter(language => {
    const searchable = normalizeSearch(`${language.name} ${language.english} ${language.code}`);
    return words.every(word => searchable.includes(word));
  });
}
