# Drive Batch

Tiện ích Chrome Manifest V3 tải hàng loạt link Google Drive, giao diện tiếng Việt. Không có bước cấu hình OAuth, API key hoặc máy chủ trung gian.

## Cài vào Chrome

1. Giải nén nếu dùng bản ZIP.
2. Mở `chrome://extensions` trong Chrome.
3. Bật **Chế độ dành cho nhà phát triển / Developer mode**.
4. Chọn **Tải tiện ích đã giải nén / Load unpacked**, chọn thư mục chứa `manifest.json` (thư mục **Driver Download** nếu dùng mã nguồn này).
5. Ghim **Drive Batch** và bấm biểu tượng để mở giao diện.

Xem `help.html` trong tiện ích để biết cách dùng. Không cần npm hoặc build để cài.

## Chức năng và giới hạn

- Dán nhiều link; lọc host/protocol, báo link lỗi và bỏ trùng theo ID.
- Kiểm tra khả năng tải không cookie, rồi thử với phiên Google trên Chrome nếu cần.
- Tải hai file cùng lúc; lưu hàng đợi, kiểm tra trạng thái bằng Chrome Downloads, dừng bắt đầu file mới, thử lại lỗi đã chọn.
- Xuất Docs → DOCX, Sheets → XLSX, Slides → PPTX; file thông thường giữ định dạng gốc. Với link `/file/d`, thử nhận diện tài liệu qua trang đích; nếu không được hãy dán link từ ứng dụng Docs/Sheets/Slides.
- Thư mục: hộp lựa chọn tự mở khi phát hiện; thử đọc embedded folder view, hiển thị checkbox chọn từng mục/tất cả. Có thể đọc các mục đang hiển thị trong tab Drive và tích lũy qua nhiều lần quét sau khi cuộn. Thư mục con cần quét riêng.
- **Không bảo đảm quét đủ mọi mục hoặc toàn bộ cây thư mục** trong chế độ không API. Nút tải cả thư mục mở Drive; người dùng bấm menu thư mục → Tải xuống để Google tạo ZIP. Đây là thao tác tải ZIP thủ công, không phải tự động tải cả thư mục.
- Không cấu hình đăng nhập riêng. Có thể cần mở Google, đăng nhập đúng tài khoản, xử lý quyền/xác nhận rồi thử lại. Không có bộ chọn nhiều tài khoản.
- Không khẳng định thiếu quyền khi Google chỉ trả 404/403 mơ hồ. Không vượt chặn tải hoặc quota; file lớn có màn hình xác nhận có thể cần tải trực tiếp trong Google.
- Kiểm tra tải dùng GET nhưng hủy response stream sau khi đọc header (hoặc một phần HTML lỗi); không giữ file lớn trong RAM. File thực tế do Chrome Downloads tải, không qua blob URL.
- Không tự tiếp tục lượt tải ở trạng thái không chắc chắn khi worker bị dừng giữa chừng, tránh tải trùng. Các lượt tải đã ghi nhận được đối chiếu với Chrome.

## Kiểm tra

`npm test` hoặc `node --test tests/*.test.js` (Node 18+).

Kiểm thử mô phỏng Google/Chrome để xác minh parser, xuất định dạng, phân loại lỗi, giới hạn hàng đợi, dừng và khôi phục worker. Chúng không thay thế thử nghiệm với Google Drive thật.

Kiểm tra thủ công khi cài:

- File công khai nhỏ, tên Unicode và file trùng tên.
- Một file Docs, Sheets, Slides công khai.
- File riêng tư có quyền, không có quyền, file bị xóa, nhiều tài khoản.
- File lớn có xác nhận Google, file có quota, chủ sở hữu cấm tải.
- Thư mục công khai, riêng tư, thư mục con, thư mục nhiều mục; cuộn rồi quét lại.
- Ba file để kiểm tra giới hạn hai lượt cùng lúc; dừng giữa bước kiểm tra; đóng tab tiện ích và khởi động lại Chrome.

## Cấu trúc

- `core.js`: xử lý link và phản hồi tải.
- `background.js`: service worker, hàng đợi lưu cục bộ, Google fetch, Chrome Downloads, quét tab Drive.
- `index.html`, `app.js`, `style.css`: giao diện.
- `help.html`: hướng dẫn trong tiện ích.
- `tests/`: kiểm thử logic và Chrome/Google mock.

Tài liệu nền: [Chrome Downloads](https://developer.chrome.com/docs/extensions/reference/api/downloads), [Google Drive downloads](https://developers.google.com/workspace/drive/api/guides/manage-downloads). Muốn liệt kê thư mục đầy đủ, ổn định hơn cần tích hợp Drive API với API key cho thư mục công khai và OAuth cho dữ liệu riêng tư; bản này chưa triển khai.
