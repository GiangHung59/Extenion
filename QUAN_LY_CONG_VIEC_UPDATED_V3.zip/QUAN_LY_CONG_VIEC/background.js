// Background script để xử lý các tác vụ nền và hiển thị thông báo
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension đã được cài đặt');
  
  // Khởi tạo các giá trị mặc định
  chrome.storage.sync.get(['tasks', 'notificationSettings', 'telegramSettings'], (result) => {
    if (!result.tasks) {
      chrome.storage.sync.set({ tasks: [] });
    }
    
    if (!result.notificationSettings) {
      chrome.storage.sync.set({ 
        notificationSettings: {
          time: '5',
          customTime: '5'
        } 
      });
    }
    
    if (!result.telegramSettings) {
      chrome.storage.sync.set({ 
        telegramSettings: {
          botToken: '',
          chatId: ''
        } 
      });
    }
  });
});

// Lắng nghe tin nhắn từ popup hoặc content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'showNotification') {
    // Hiển thị thông báo trên tất cả các tab
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          action: 'showTimeoutNotification',
          task: message.task,
          taskIndex: message.taskIndex
        }).catch(err => {
          // Bỏ qua lỗi nếu tab không có content script
          console.log(`Không thể gửi thông báo đến tab ${tab.id}: ${err.message}`);
        });
      });
    });
  }
});

// Kiểm tra công việc hết thời gian định kỳ
function checkTimeoutTasks() {
  chrome.storage.sync.get(['tasks', 'notificationSettings', 'telegramSettings'], (result) => {
    const tasks = result.tasks || [];
    const now = new Date();
    let updated = false;
    
    // Lấy thời gian thông báo từ cài đặt
    let notificationTime = 5; // Mặc định 5 phút
    if (result.notificationSettings) {
      if (result.notificationSettings.time === 'custom') {
        notificationTime = parseInt(result.notificationSettings.customTime) || 5;
      } else {
        notificationTime = parseInt(result.notificationSettings.time) || 5;
      }
    }
    
    tasks.forEach((task, index) => {
      if (!task.completed) {
        const endDateTime = new Date(`${task.endDate}T${task.endTime}`);
        const timeDiff = endDateTime - now; // milliseconds
        const minutesDiff = timeDiff / (1000 * 60); // convert to minutes
        
        // Kiểm tra nếu công việc gần hết thời gian (còn notificationTime phút) và chưa thông báo
        if (minutesDiff > 0 && minutesDiff <= notificationTime && !task.notified) {
          // Đánh dấu đã thông báo để tránh thông báo nhiều lần
          tasks[index].notified = true;
          updated = true;
          
          // Gửi thông báo Telegram nếu đã cấu hình
          if (result.telegramSettings && result.telegramSettings.botToken && result.telegramSettings.chatId) {
            sendTelegramNotification(task, result.telegramSettings);
          }
          
          // Gửi thông báo đến tất cả các tab
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'showTimeoutNotification',
                task: task,
                taskIndex: index
              }).catch(err => {
                // Bỏ qua lỗi nếu tab không có content script
                console.log(`Không thể gửi thông báo đến tab ${tab.id}: ${err.message}`);
              });
            });
          });
        }
        
        // Kiểm tra nếu công việc đã hết thời gian và chưa thông báo
        if (endDateTime <= now && !task.notified) {
          // Đánh dấu đã thông báo để tránh thông báo nhiều lần
          tasks[index].notified = true;
          updated = true;
          
          // Gửi thông báo đến tất cả các tab
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'showTimeoutNotification',
                task: task,
                taskIndex: index
              }).catch(err => {
                // Bỏ qua lỗi nếu tab không có content script
                console.log(`Không thể gửi thông báo đến tab ${tab.id}: ${err.message}`);
              });
            });
          });
        }
      }
    });
    
    if (updated) {
      chrome.storage.sync.set({ tasks });
    }
  });
}

// Hàm gửi thông báo qua Telegram
function sendTelegramNotification(task, telegramSettings) {
  const botToken = telegramSettings.botToken;
  const chatId = telegramSettings.chatId;
  
  const message = `⚠️ Công việc sắp hết hạn!\n\n📝 ${task.name}\n🕒 ${task.startTime} - ${task.endTime}\n📅 ${formatDate(task.endDate)}`;
  
  fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      parse_mode: 'HTML'
    })
  }).catch(error => console.error('Lỗi gửi thông báo Telegram:', error));
}

// Hàm định dạng ngày
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('vi-VN');
}

// Kiểm tra mỗi phút
setInterval(checkTimeoutTasks, 60000);
