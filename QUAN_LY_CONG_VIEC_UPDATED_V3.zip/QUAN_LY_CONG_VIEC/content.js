// Content script để hiển thị panel nổi và thông báo trên tất cả các tab
(function() {
  // Tạo style cho panel nổi và thông báo
  const style = document.createElement('style');
  style.textContent = `
    #floatingPanel {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 350px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 9999;
      overflow: hidden;
      resize: both;
      min-width: 300px;
      min-height: 200px;
      max-width: 600px;
      max-height: 800px;
      font-family: Arial, sans-serif;
    }

    .panel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 15px;
      background-color: #2196f3;
      color: white;
      cursor: move;
    }

    .panel-header h3 {
      margin: 0;
      font-size: 16px;
    }

    .panel-actions {
      display: flex;
      gap: 10px;
    }

    .panel-actions button {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      font-size: 16px;
    }

    .panel-content {
      padding: 15px;
      max-height: calc(100% - 40px);
      overflow-y: auto;
    }

    /* Task List Styles */
    .task-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .task-item {
      display: flex;
      flex-direction: column;
      margin: 8px 0;
      padding: 12px;
      background-color: #ffffff;
      border: 1px solid #ddd;
      border-radius: 6px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      transition: opacity 0.3s, background-color 0.3s;
    }

    .task-item.completed {
      text-decoration: line-through;
      opacity: 0.7;
      background-color: #f5f5f5;
    }

    .task-item.warning {
      background-color: #ffebee;
      border: 2px solid #f44336;
      animation: blink-border 1s infinite;
    }

    .task-item.high-priority {
      border-left: 4px solid #f44336;
    }

    .task-item.medium-priority {
      border-left: 4px solid #ff9800;
    }

    .task-item.low-priority {
      border-left: 4px solid #4caf50;
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 5px;
    }

    .task-checkbox {
      margin-right: 8px;
      cursor: pointer;
    }

    .task-name {
      font-weight: bold;
      flex-grow: 1;
    }

    .task-actions {
      display: flex;
      gap: 5px;
    }

    .task-actions i {
      cursor: pointer;
      padding: 5px;
      color: #757575;
      transition: color 0.2s;
    }

    .task-actions i.fa-edit:hover {
      color: #ff9800;
    }

    .task-actions i.fa-trash-alt:hover {
      color: #f44336;
    }

    .task-actions i.fa-filter:hover {
      color: #2196f3;
    }

    .task-date {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #666;
      margin: 5px 0;
    }

    .task-time {
      color: #1e88e5;
      font-size: 13px;
      font-weight: bold;
    }

    .task-priority {
      font-size: 12px;
      margin-top: 5px;
    }

    .task-priority.high {
      color: #f44336;
    }

    .task-priority.medium {
      color: #ff9800;
    }

    .task-priority.low {
      color: #4caf50;
    }

    .task-item.warning .task-time {
      color: #d32f2f;
    }

    /* Edit Form Styles */
    .edit-form {
      background-color: #e0f7fa;
      padding: 10px;
      border-radius: 4px;
      margin-top: 10px;
      display: none;
    }

    .edit-form input,
    .edit-form select {
      width: 100%;
      padding: 8px;
      margin: 5px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .edit-form .date-container {
      display: flex;
      gap: 10px;
      margin: 5px 0;
    }

    .edit-form .date-container > div {
      flex: 1;
    }

    .edit-form .time-container {
      display: flex;
      gap: 10px;
      margin: 5px 0;
    }

    .edit-form .time-container > div {
      flex: 1;
    }

    .edit-form label {
      display: block;
      font-size: 12px;
      color: #666;
      margin-bottom: 3px;
    }

    .edit-form-buttons {
      display: flex;
      gap: 10px;
      margin-top: 10px;
    }

    .edit-form-buttons button {
      flex: 1;
      padding: 8px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }

    .edit-form-buttons .save-btn {
      background-color: #4CAF50;
      color: white;
    }

    .edit-form-buttons .save-btn:hover {
      background-color: #45a049;
    }

    .edit-form-buttons .cancel-btn {
      background-color: #f44336;
      color: white;
    }

    .edit-form-buttons .cancel-btn:hover {
      background-color: #d32f2f;
    }

    /* Add Task Form Styles */
    .add-task-button {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      margin-bottom: 10px;
    }

    .add-task-button:hover {
      background-color: #45a049;
    }

    .add-task-form {
      background-color: #f0f8ff;
      padding: 15px;
      border-radius: 6px;
      margin-bottom: 15px;
      display: none;
    }

    .add-task-form input,
    .add-task-form select {
      width: 100%;
      padding: 8px;
      margin: 5px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .add-task-form .date-container {
      display: flex;
      gap: 10px;
      margin: 5px 0;
    }

    .add-task-form .date-container > div {
      flex: 1;
    }

    .add-task-form .time-container {
      display: flex;
      gap: 10px;
      margin: 5px 0;
    }

    .add-task-form .time-container > div {
      flex: 1;
    }

    .add-task-form label {
      display: block;
      font-size: 12px;
      color: #666;
      margin-bottom: 3px;
    }

    .add-task-form-buttons {
      display: flex;
      gap: 10px;
      margin-top: 10px;
    }

    .add-task-form-buttons button {
      flex: 1;
      padding: 8px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }

    .add-task-form-buttons .add-btn {
      background-color: #4CAF50;
      color: white;
    }

    .add-task-form-buttons .add-btn:hover {
      background-color: #45a049;
    }

    .add-task-form-buttons .cancel-btn {
      background-color: #f44336;
      color: white;
    }

    .add-task-form-buttons .cancel-btn:hover {
      background-color: #d32f2f;
    }

    /* Filter Styles */
    .filter-container {
      background-color: #f0f8ff;
      padding: 10px;
      border-radius: 6px;
      margin-bottom: 15px;
      display: none;
    }

    .filter-container select {
      width: 100%;
      padding: 8px;
      margin: 5px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .filter-container .show-completed {
      display: flex;
      align-items: center;
      margin-top: 10px;
    }

    .filter-container .show-completed input {
      margin-right: 5px;
    }

    /* Timeout Notification Styles */
    #timeoutNotification {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      z-index: 10000;
      text-align: center;
      min-width: 350px;
      animation: blink-background 1s infinite;
    }

    #timeoutNotification h3 {
      margin-top: 0;
      color: #d32f2f;
      font-size: 20px;
    }

    #timeoutNotification .task-name {
      font-size: 22px;
      font-weight: bold;
      margin: 15px 0;
    }

    #timeoutNotification .task-time {
      font-size: 18px;
      color: #d32f2f;
      margin: 10px 0;
    }

    #timeoutNotification .notification-buttons {
      display: flex;
      justify-content: center;
      gap: 15px;
      margin-top: 20px;
    }

    #timeoutNotification button {
      padding: 10px 25px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s;
    }

    #timeoutNotification #taskDone {
      background-color: #4CAF50;
      color: white;
    }

    #timeoutNotification #taskDone:hover {
      background-color: #45a049;
    }

    #timeoutNotification #taskExtend {
      background-color: #ff9800;
      color: white;
    }

    #timeoutNotification #taskExtend:hover {
      background-color: #e68a00;
    }

    #timeoutNotification .extend-time {
      margin-top: 15px;
      display: none;
    }

    #timeoutNotification .extend-time input {
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      margin-right: 10px;
      font-size: 16px;
    }

    #timeoutNotification .extend-time button {
      background-color: #2196F3;
      color: white;
    }

    #timeoutNotification .extend-time button:hover {
      background-color: #0b7dda;
    }

    /* Animations */
    @keyframes blink-border {
      0% {
        border-color: #f44336;
        box-shadow: 0 0 5px #f44336;
      }
      50% {
        border-color: #ff7961;
        box-shadow: 0 0 10px #ff7961;
      }
      100% {
        border-color: #f44336;
        box-shadow: 0 0 5px #f44336;
      }
    }

    @keyframes blink-background {
      0% {
        background-color: rgba(255, 255, 255, 0.95);
      }
      50% {
        background-color: rgba(255, 235, 238, 0.95);
      }
      100% {
        background-color: rgba(255, 255, 255, 0.95);
      }
    }
  `;
  document.head.appendChild(style);

  // Tạo panel nổi
  function createFloatingPanel() {
    // Kiểm tra xem panel đã tồn tại chưa
    if (document.getElementById('floatingPanel')) {
      document.getElementById('floatingPanel').style.display = 'block';
      return;
    }
    
    const panel = document.createElement('div');
    panel.id = 'floatingPanel';
    panel.innerHTML = `
      <div class="panel-header">
        <h3>Quản lý công việc</h3>
        <div class="panel-actions">
          <button id="toggleFilter" title="Lọc công việc"><i class="fas fa-filter"></i></button>
          <button id="closePanel" title="Đóng panel"><i class="fas fa-times"></i></button>
        </div>
      </div>
      <div class="panel-content">
        <div class="filter-container" id="filterContainer">
          <select id="priorityFilter">
            <option value="all">Tất cả mức độ</option>
            <option value="high">Quan trọng cao</option>
            <option value="medium">Quan trọng trung bình</option>
            <option value="low">Quan trọng thấp</option>
          </select>
          <select id="dateFilter">
            <option value="all">Tất cả thời gian</option>
            <option value="today">Hôm nay</option>
            <option value="tomorrow">Ngày mai</option>
            <option value="week">Tuần này</option>
          </select>
          <label class="show-completed">
            <input type="checkbox" id="showCompleted"> Hiện công việc đã hoàn thành
          </label>
        </div>
        
        <button class="add-task-button" id="addTaskButton">Thêm việc cần làm</button>
        
        <div class="add-task-form" id="addTaskForm">
          <input type="text" id="taskInput" placeholder="Nhập việc cần làm...">
          
          <div class="date-container">
            <div>
              <label for="taskStartDate">Ngày bắt đầu</label>
              <input type="date" id="taskStartDate">
            </div>
            <div>
              <label for="taskEndDate">Ngày kết thúc</label>
              <input type="date" id="taskEndDate">
            </div>
          </div>
          
          <div class="time-container">
            <div>
              <label for="startTime">Thời gian bắt đầu</label>
              <input type="time" id="startTime">
            </div>
            <div>
              <label for="endTime">Thời gian kết thúc</label>
              <input type="time" id="endTime">
            </div>
          </div>
          
          <div>
            <label for="taskPriority">Mức độ quan trọng</label>
            <select id="taskPriority">
              <option value="high">Cao</option>
              <option value="medium" selected>Trung bình</option>
              <option value="low">Thấp</option>
            </select>
          </div>
          
          <div class="add-task-form-buttons">
            <button class="add-btn" id="addTask">Thêm</button>
            <button class="cancel-btn" id="cancelAddTask">Hủy</button>
          </div>
        </div>
        
        <ul class="task-list" id="taskList"></ul>
      </div>
    `;
    
    document.body.appendChild(panel);
    
    // Thêm Font Awesome nếu chưa có
    if (!document.querySelector('link[href*="font-awesome"]')) {
      const fontAwesome = document.createElement('link');
      fontAwesome.rel = 'stylesheet';
      fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css';
      document.head.appendChild(fontAwesome);
    }
    
    // Xử lý sự kiện đóng panel
    document.getElementById('closePanel').addEventListener('click', () => {
      panel.style.display = 'none';
    });
    
    // Xử lý sự kiện hiển thị/ẩn bộ lọc
    document.getElementById('toggleFilter').addEventListener('click', () => {
      const filterContainer = document.getElementById('filterContainer');
      filterContainer.style.display = filterContainer.style.display === 'none' || filterContainer.style.display === '' ? 'block' : 'none';
    });
    
    // Xử lý sự kiện hiển thị/ẩn form thêm công việc
    document.getElementById('addTaskButton').addEventListener('click', () => {
      document.getElementById('addTaskForm').style.display = 'block';
      document.getElementById('addTaskButton').style.display = 'none';
      
      // Thiết lập thời gian mặc định
      setDefaultTimes();
    });
    
    document.getElementById('cancelAddTask').addEventListener('click', () => {
      document.getElementById('addTaskForm').style.display = 'none';
      document.getElementById('addTaskButton').style.display = 'block';
    });
    
    // Xử lý sự kiện thêm công việc
    document.getElementById('addTask').addEventListener('click', addNewTask);
    
    // Xử lý sự kiện lọc
    document.getElementById('priorityFilter').addEventListener('change', loadTasks);
    document.getElementById('dateFilter').addEventListener('change', loadTasks);
    document.getElementById('showCompleted').addEventListener('change', loadTasks);
    
    // Xử lý kéo thả panel
    makeDraggable(panel);
    
    // Cập nhật nội dung panel
    loadTasks();
  }
  
  // Thiết lập thời gian mặc định
  function setDefaultTimes() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    // Ngày hiện tại
    const today = `${year}-${month}-${day}`;
    document.getElementById('taskStartDate').value = today;
    document.getElementById('taskEndDate').value = today;
    
    // Thời gian hiện tại
    document.getElementById('startTime').value = `${hours}:${minutes}`;
    
    // Thời gian kết thúc (hiện tại + 45 phút)
    const endTime = new Date(now.getTime() + 45 * 60000);
    const endHours = String(endTime.getHours()).padStart(2, '0');
    const endMinutes = String(endTime.getMinutes()).padStart(2, '0');
    document.getElementById('endTime').value = `${endHours}:${endMinutes}`;
  }
  
  // Hàm thêm công việc mới
  function addNewTask() {
    const taskInput = document.getElementById('taskInput');
    const taskStartDateInput = document.getElementById('taskStartDate');
    const taskEndDateInput = document.getElementById('taskEndDate');
    const startTimeInput = document.getElementById('startTime');
    const endTimeInput = document.getElementById('endTime');
    const taskPrioritySelect = document.getElementById('taskPriority');
    
    const taskName = taskInput.value.trim();
    const taskStartDate = taskStartDateInput.value;
    const taskEndDate = taskEndDateInput.value;
    const startTime = startTimeInput.value;
    const endTime = endTimeInput.value;
    const priority = taskPrioritySelect.value;

    // Kiểm tra đầu vào
    if (!taskName) {
      alert('Vui lòng nhập tên công việc!');
      return;
    }
    if (!taskStartDate || !taskEndDate) {
      alert('Vui lòng chọn ngày bắt đầu và ngày kết thúc!');
      return;
    }
    if (new Date(taskEndDate) < new Date(taskStartDate)) {
      alert('Ngày kết thúc phải sau hoặc bằng ngày bắt đầu!');
      return;
    }
    if (!startTime || !endTime) {
      alert('Vui lòng chọn thời gian bắt đầu và kết thúc!');
      return;
    }
    if (taskStartDate === taskEndDate && startTime >= endTime) {
      alert('Thời gian kết thúc phải sau thời gian bắt đầu trong cùng ngày!');
      return;
    }

    const newTask = {
      name: taskName,
      startDate: taskStartDate,
      endDate: taskEndDate,
      startTime: startTime,
      endTime: endTime,
      priority: priority,
      completed: false,
      notified: false
    };

    // Thêm công việc mới
    chrome.storage.sync.get(['tasks'], (result) => {
      const tasks = result.tasks || [];
      tasks.push(newTask);
      chrome.storage.sync.set({ tasks }, () => {
        taskInput.value = '';
        // Ẩn form thêm công việc
        document.getElementById('addTaskForm').style.display = 'none';
        document.getElementById('addTaskButton').style.display = 'block';
        loadTasks();
      });
    });
  }
  
  // Hàm tải danh sách công việc
  function loadTasks() {
    const taskList = document.getElementById('taskList');
    const priorityFilter = document.getElementById('priorityFilter');
    const dateFilter = document.getElementById('dateFilter');
    const showCompletedCheckbox = document.getElementById('showCompleted');
    
    chrome.storage.sync.get(['tasks'], (result) => {
      const tasks = result.tasks || [];
      
      // Lọc và sắp xếp công việc
      const filteredTasks = filterTasks(tasks, priorityFilter.value, dateFilter.value, showCompletedCheckbox.checked);
      const sortedTasks = sortTasks(filteredTasks);
      
      taskList.innerHTML = '';
      sortedTasks.forEach((task, index) => {
        const li = document.createElement('li');
        li.className = `task-item ${task.priority}-priority`;
        li.dataset.index = index;
        
        // Thêm class nếu công việc đã hoàn thành
        if (task.completed) {
          li.classList.add('completed');
        }
        
        // Kiểm tra xem công việc có gần hết thời gian không
        const isNearEnd = checkNearEndTime(task);
        if (isNearEnd && !task.completed) {
          li.classList.add('warning');
        }
        
        // Tạo phần header của công việc (checkbox, tên và các nút)
        const taskHeader = document.createElement('div');
        taskHeader.className = 'task-header';
        
        // Thêm checkbox để đánh dấu hoàn thành
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'task-checkbox';
        checkbox.checked = task.completed || false;
        checkbox.onchange = () => {
          toggleTaskCompletion(index);
        };
        
        const taskName = document.createElement('div');
        taskName.className = 'task-name';
        taskName.textContent = task.name;
        
        const taskActions = document.createElement('div');
        taskActions.className = 'task-actions';
        
        // Thêm icon chỉnh sửa
        const editIcon = document.createElement('i');
        editIcon.className = 'fas fa-edit';
        editIcon.title = 'Chỉnh sửa';
        editIcon.onclick = () => {
          toggleEditForm(li, task, index);
        };
        
        // Thêm icon xóa
        const deleteIcon = document.createElement('i');
        deleteIcon.className = 'fas fa-trash-alt';
        deleteIcon.title = 'Xóa';
        deleteIcon.onclick = () => {
          deleteTask(index);
        };
        
        taskActions.appendChild(editIcon);
        taskActions.appendChild(deleteIcon);
        
        taskHeader.appendChild(checkbox);
        taskHeader.appendChild(taskName);
        taskHeader.appendChild(taskActions);
        
        // Tạo phần hiển thị ngày (trên cùng một dòng với 2 tab)
        const taskDate = document.createElement('div');
        taskDate.className = 'task-date';
        
        const startDateSpan = document.createElement('span');
        startDateSpan.textContent = `Bắt đầu: ${formatDate(task.startDate)}`;
        
        const endDateSpan = document.createElement('span');
        endDateSpan.textContent = `Kết thúc: ${formatDate(task.endDate)}`;
        
        taskDate.appendChild(startDateSpan);
        taskDate.appendChild(endDateSpan);
        
        // Tạo phần hiển thị thời gian (bên dưới phần ngày)
        const taskTime = document.createElement('div');
        taskTime.className = 'task-time';
        taskTime.textContent = `${task.startTime} - ${task.endTime}`;
        
        // Tạo phần hiển thị mức độ ưu tiên
        const taskPriority = document.createElement('div');
        taskPriority.className = `task-priority ${task.priority}`;
        
        let priorityText = '';
        switch(task.priority) {
          case 'high':
            priorityText = 'Quan trọng: Cao';
            break;
          case 'medium':
            priorityText = 'Quan trọng: Trung bình';
            break;
          case 'low':
            priorityText = 'Quan trọng: Thấp';
            break;
          default:
            priorityText = 'Quan trọng: Trung bình';
        }
        
        taskPriority.textContent = priorityText;
        
        // Thêm các phần tử vào công việc
        li.appendChild(taskHeader);
        li.appendChild(taskDate);
        li.appendChild(taskTime);
        li.appendChild(taskPriority);
        
        // Tạo form chỉnh sửa (ẩn ban đầu)
        const editForm = document.createElement('div');
        editForm.className = 'edit-form';
        editForm.innerHTML = `
          <input type="text" class="edit-task-name" placeholder="Tên công việc" value="${task.name}">
          
          <div class="date-container">
            <div>
              <label>Ngày bắt đầu</label>
              <input type="date" class="edit-start-date" value="${task.startDate}">
            </div>
            <div>
              <label>Ngày kết thúc</label>
              <input type="date" class="edit-end-date" value="${task.endDate}">
            </div>
          </div>
          
          <div class="time-container">
            <div>
              <label>Thời gian bắt đầu</label>
              <input type="time" class="edit-start-time" value="${task.startTime}">
            </div>
            <div>
              <label>Thời gian kết thúc</label>
              <input type="time" class="edit-end-time" value="${task.endTime}">
            </div>
          </div>
          
          <div>
            <label>Mức độ quan trọng</label>
            <select class="edit-priority">
              <option value="high" ${task.priority === 'high' ? 'selected' : ''}>Cao</option>
              <option value="medium" ${task.priority === 'medium' ? 'selected' : ''}>Trung bình</option>
              <option value="low" ${task.priority === 'low' ? 'selected' : ''}>Thấp</option>
            </select>
          </div>
          
          <div class="edit-form-buttons">
            <button class="save-btn">Lưu</button>
            <button class="cancel-btn">Hủy</button>
          </div>
        `;
        
        li.appendChild(editForm);
        
        // Xử lý sự kiện nút lưu
        editForm.querySelector('.save-btn').addEventListener('click', () => {
          saveTaskEdit(li, index);
        });
        
        // Xử lý sự kiện nút hủy
        editForm.querySelector('.cancel-btn').addEventListener('click', () => {
          editForm.style.display = 'none';
        });
        
        taskList.appendChild(li);
      });
    });
  }
  
  // Hàm hiển thị/ẩn form chỉnh sửa
  function toggleEditForm(taskItem, task, index) {
    const editForm = taskItem.querySelector('.edit-form');
    editForm.style.display = editForm.style.display === 'none' || editForm.style.display === '' ? 'block' : 'none';
  }
  
  // Hàm lưu chỉnh sửa công việc
  function saveTaskEdit(taskItem, index) {
    const editForm = taskItem.querySelector('.edit-form');
    const taskName = editForm.querySelector('.edit-task-name').value.trim();
    const taskStartDate = editForm.querySelector('.edit-start-date').value;
    const taskEndDate = editForm.querySelector('.edit-end-date').value;
    const startTime = editForm.querySelector('.edit-start-time').value;
    const endTime = editForm.querySelector('.edit-end-time').value;
    const priority = editForm.querySelector('.edit-priority').value;

    // Kiểm tra đầu vào
    if (!taskName) {
      alert('Vui lòng nhập tên công việc!');
      return;
    }
    if (!taskStartDate || !taskEndDate) {
      alert('Vui lòng chọn ngày bắt đầu và ngày kết thúc!');
      return;
    }
    if (new Date(taskEndDate) < new Date(taskStartDate)) {
      alert('Ngày kết thúc phải sau hoặc bằng ngày bắt đầu!');
      return;
    }
    if (!startTime || !endTime) {
      alert('Vui lòng chọn thời gian bắt đầu và kết thúc!');
      return;
    }
    if (taskStartDate === taskEndDate && startTime >= endTime) {
      alert('Thời gian kết thúc phải sau thời gian bắt đầu trong cùng ngày!');
      return;
    }

    chrome.storage.sync.get(['tasks'], (result) => {
      const tasks = result.tasks || [];
      
      if (tasks[index]) {
        // Giữ lại trạng thái hoàn thành
        const completed = tasks[index].completed || false;
        
        // Cập nhật công việc
        tasks[index] = {
          name: taskName,
          startDate: taskStartDate,
          endDate: taskEndDate,
          startTime: startTime,
          endTime: endTime,
          priority: priority,
          completed: completed,
          notified: false // Reset trạng thái thông báo
        };
        
        chrome.storage.sync.set({ tasks }, () => {
          editForm.style.display = 'none';
          loadTasks(); // Tải lại danh sách công việc để cập nhật giao diện
        });
      }
    });
  }
  
  // Hàm xóa công việc
  function deleteTask(index) {
    if (confirm('Bạn có chắc muốn xóa công việc này?')) {
      chrome.storage.sync.get(['tasks'], (result) => {
        const tasks = result.tasks || [];
        tasks.splice(index, 1);
        chrome.storage.sync.set({ tasks }, () => {
          loadTasks();
        });
      });
    }
  }
  
  // Hàm đánh dấu hoàn thành/chưa hoàn thành công việc
  function toggleTaskCompletion(index) {
    chrome.storage.sync.get(['tasks'], (result) => {
      const tasks = result.tasks || [];
      if (tasks[index]) {
        tasks[index].completed = !tasks[index].completed;
        chrome.storage.sync.set({ tasks }, () => {
          loadTasks();
        });
      }
    });
  }
  
  // Hàm lọc công việc theo bộ lọc
  function filterTasks(tasks, priorityFilter, dateFilter, showCompleted) {
    return tasks.filter(task => {
      // Lọc theo trạng thái hoàn thành
      if (!showCompleted && task.completed) {
        return false;
      }
      
      // Lọc theo mức độ ưu tiên
      if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
        return false;
      }
      
      // Lọc theo ngày
      if (dateFilter !== 'all') {
        const taskDate = new Date(task.endDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);
        
        switch(dateFilter) {
          case 'today':
            if (taskDate.toDateString() !== today.toDateString()) {
              return false;
            }
            break;
          case 'tomorrow':
            if (taskDate.toDateString() !== tomorrow.toDateString()) {
              return false;
            }
            break;
          case 'week':
            if (taskDate < today || taskDate >= nextWeek) {
              return false;
            }
            break;
        }
      }
      
      return true;
    });
  }
  
  // Hàm sắp xếp công việc
  function sortTasks(tasks) {
    return [...tasks].sort((a, b) => {
      // 1. Ưu tiên theo mức độ quan trọng (cao -> trung bình -> thấp)
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
      if (priorityDiff !== 0) return priorityDiff;
      
      // 2. Ưu tiên công việc chưa hoàn thành
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      
      // 3. Ưu tiên công việc gần đến hạn
      const aEndDateTime = new Date(`${a.endDate}T${a.endTime}`);
      const bEndDateTime = new Date(`${b.endDate}T${b.endTime}`);
      return aEndDateTime - bEndDateTime;
    });
  }
  
  // Hàm định dạng ngày
  function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN');
  }

  // Hàm kiểm tra xem công việc có gần hết thời gian không
  function checkNearEndTime(task) {
    // Lấy thời gian thông báo từ cài đặt
    return new Promise((resolve) => {
      chrome.storage.sync.get(['notificationSettings'], (result) => {
        let notificationTime = 5; // Mặc định 5 phút
        
        if (result.notificationSettings) {
          if (result.notificationSettings.time === 'custom') {
            notificationTime = parseInt(result.notificationSettings.customTime) || 5;
          } else {
            notificationTime = parseInt(result.notificationSettings.time) || 5;
          }
        }
        
        const now = new Date();
        const endDateTime = new Date(`${task.endDate}T${task.endTime}`);
        const timeDiff = endDateTime - now; // milliseconds
        const minutesDiff = timeDiff / (1000 * 60); // convert to minutes
        resolve(minutesDiff > 0 && minutesDiff <= notificationTime);
      });
    });
  }

  // Hàm kiểm tra công việc hết thời gian
  function checkTimeoutTasks() {
    chrome.storage.sync.get(['tasks', 'notificationSettings'], (result) => {
      const tasks = result.tasks || [];
      const now = new Date();
      
      let notificationTime = 5; // Mặc định 5 phút
      if (result.notificationSettings) {
        if (result.notificationSettings.time === 'custom') {
          notificationTime = parseInt(result.notificationSettings.customTime) || 5;
        } else {
          notificationTime = parseInt(result.notificationSettings.time) || 5;
        }
      }
      
      tasks.forEach((task, index) => {
        if (!task.completed) {
          const endDateTime = new Date(`${task.endDate}T${task.endTime}`);
          const timeDiff = endDateTime - now; // milliseconds
          const minutesDiff = timeDiff / (1000 * 60); // convert to minutes
          
          // Kiểm tra nếu công việc gần hết thời gian (còn notificationTime phút) và chưa thông báo
          if (minutesDiff > 0 && minutesDiff <= notificationTime && !task.notified) {
            // Đánh dấu đã thông báo để tránh thông báo nhiều lần
            tasks[index].notified = true;
            chrome.storage.sync.set({ tasks }, () => {
              // Gửi thông báo Telegram nếu đã cấu hình
              sendTelegramNotification(task);
              
              // Hiển thị thông báo trên màn hình
              showTimeoutNotification(task, index);
            });
          }
          
          // Kiểm tra nếu công việc đã hết thời gian và chưa thông báo
          if (endDateTime <= now && !task.notified) {
            // Đánh dấu đã thông báo để tránh thông báo nhiều lần
            tasks[index].notified = true;
            chrome.storage.sync.set({ tasks }, () => {
              // Hiển thị thông báo trên màn hình
              showTimeoutNotification(task, index);
            });
          }
        }
      });
    });
  }
  
  // Hàm gửi thông báo qua Telegram
  function sendTelegramNotification(task) {
    chrome.storage.sync.get(['telegramSettings'], (result) => {
      if (result.telegramSettings && result.telegramSettings.botToken && result.telegramSettings.chatId) {
        const botToken = result.telegramSettings.botToken;
        const chatId = result.telegramSettings.chatId;
        
        const message = `⚠️ Công việc sắp hết hạn!\n\n📝 ${task.name}\n🕒 ${task.startTime} - ${task.endTime}\n📅 ${formatDate(task.endDate)}`;
        
        fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'HTML'
          })
        }).catch(error => console.error('Lỗi gửi thông báo Telegram:', error));
      }
    });
  }
  
  // Hiển thị thông báo hết thời gian
  function showTimeoutNotification(task, taskIndex) {
    // Xóa thông báo cũ nếu có
    const oldNotification = document.getElementById('timeoutNotification');
    if (oldNotification) {
      oldNotification.remove();
    }
    
    // Tạo thông báo mới
    const notification = document.createElement('div');
    notification.id = 'timeoutNotification';
    notification.innerHTML = `
      <h3>Công việc đã hết thời gian!</h3>
      <div class="task-name">${task.name}</div>
      <div class="task-time">${task.startTime} - ${task.endTime}</div>
      <div class="notification-buttons">
        <button id="taskDone">Đã xong</button>
        <button id="taskExtend">Gia hạn</button>
      </div>
      <div class="extend-time">
        <input type="time" id="extendTime">
        <button id="confirmExtend">Xác nhận</button>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // Xử lý sự kiện nút "Đã xong"
    document.getElementById('taskDone').addEventListener('click', () => {
      chrome.storage.sync.get(['tasks'], (result) => {
        const tasks = result.tasks || [];
        tasks[taskIndex].completed = true;
        chrome.storage.sync.set({ tasks }, () => {
          notification.remove();
          loadTasks();
        });
      });
    });
    
    // Xử lý sự kiện nút "Gia hạn"
    document.getElementById('taskExtend').addEventListener('click', () => {
      const extendTimeDiv = notification.querySelector('.extend-time');
      extendTimeDiv.style.display = 'block';
      
      // Thiết lập thời gian mặc định (hiện tại + 45 phút)
      const now = new Date();
      const extendTime = new Date(now.getTime() + 45 * 60000);
      const hours = String(extendTime.getHours()).padStart(2, '0');
      const minutes = String(extendTime.getMinutes()).padStart(2, '0');
      document.getElementById('extendTime').value = `${hours}:${minutes}`;
    });
    
    // Xử lý sự kiện nút "Xác nhận" gia hạn
    document.getElementById('confirmExtend').addEventListener('click', () => {
      const newEndTime = document.getElementById('extendTime').value;
      
      chrome.storage.sync.get(['tasks'], (result) => {
        const tasks = result.tasks || [];
        
        // Cập nhật thời gian kết thúc và đánh dấu là chưa thông báo
        tasks[taskIndex].endTime = newEndTime;
        tasks[taskIndex].notified = false;
        
        // Nếu ngày kết thúc là ngày trong quá khứ, cập nhật thành ngày hiện tại
        const now = new Date();
        const taskEndDate = new Date(tasks[taskIndex].endDate);
        if (taskEndDate < now) {
          const year = now.getFullYear();
          const month = String(now.getMonth() + 1).padStart(2, '0');
          const day = String(now.getDate()).padStart(2, '0');
          tasks[taskIndex].endDate = `${year}-${month}-${day}`;
        }
        
        chrome.storage.sync.set({ tasks }, () => {
          notification.remove();
          loadTasks();
        });
      });
    });
  }
  
  // Hàm làm cho panel có thể kéo thả
  function makeDraggable(element) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    
    element.querySelector('.panel-header').onmousedown = dragMouseDown;
    
    function dragMouseDown(e) {
      e = e || window.event;
      e.preventDefault();
      // Lấy vị trí chuột khi bắt đầu
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      // Gọi hàm khi di chuyển chuột
      document.onmousemove = elementDrag;
    }
    
    function elementDrag(e) {
      e = e || window.event;
      e.preventDefault();
      // Tính toán vị trí mới
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      // Đặt vị trí mới của phần tử
      element.style.top = (element.offsetTop - pos2) + "px";
      element.style.left = (element.offsetLeft - pos1) + "px";
    }
    
    function closeDragElement() {
      // Dừng di chuyển khi nhả chuột
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }
  
  // Đăng ký phím tắt ALT+S để ẩn/hiện panel
  document.addEventListener('keydown', function(e) {
    if (e.altKey && e.key === 's') {
      const panel = document.getElementById('floatingPanel');
      if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      } else {
        createFloatingPanel();
      }
    }
  });
  
  // Lắng nghe tin nhắn từ background script hoặc popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'showPanel') {
      createFloatingPanel();
    } else if (message.action === 'showTimeoutNotification') {
      showTimeoutNotification(message.task, message.taskIndex);
    }
  });
  
  // Tạo panel nổi khi trang được tải
  setTimeout(createFloatingPanel, 1000);
  
  // Kiểm tra công việc hết thời gian mỗi phút
  setInterval(checkTimeoutTasks, 60000);
})();
