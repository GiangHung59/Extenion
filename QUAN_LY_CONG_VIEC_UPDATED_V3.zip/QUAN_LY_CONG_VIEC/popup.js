document.addEventListener('DOMContentLoaded', function () {
  // Popup UI elements
  const notificationTimeSelect = document.getElementById('notificationTime');
  const customTimeContainer = document.getElementById('customTimeContainer');
  const customNotificationTimeInput = document.getElementById('customNotificationTime');
  const telegramBotTokenInput = document.getElementById('telegramBotToken');
  const telegramChatIdInput = document.getElementById('telegramChatId');
  const showHideTokenBtn = document.getElementById('showHideToken');
  const saveTelegramSettingsBtn = document.getElementById('saveTelegramSettings');
  const resetTelegramSettingsBtn = document.getElementById('resetTelegramSettings');
  const exportDataBtn = document.getElementById('exportData');
  const importDataBtn = document.getElementById('importData');
  const importFileInput = document.getElementById('importFile');
  const showPanelBtn = document.getElementById('showPanel');

  // Load settings
  function loadSettings() {
    chrome.storage.sync.get(['notificationSettings', 'telegramSettings'], (result) => {
      // Load notification settings
      if (result.notificationSettings) {
        if (result.notificationSettings.time === 'custom') {
          notificationTimeSelect.value = 'custom';
          customTimeContainer.style.display = 'block';
          customNotificationTimeInput.value = result.notificationSettings.customTime || 5;
        } else {
          notificationTimeSelect.value = result.notificationSettings.time || '5';
        }
      }

      // Load Telegram settings
      if (result.telegramSettings) {
        telegramBotTokenInput.value = result.telegramSettings.botToken || '';
        telegramChatIdInput.value = result.telegramSettings.chatId || '';
      }
    });
  }

  // Event listeners for popup UI
  notificationTimeSelect.addEventListener('change', function() {
    if (this.value === 'custom') {
      customTimeContainer.style.display = 'block';
    } else {
      customTimeContainer.style.display = 'none';
    }
    
    saveNotificationSettings();
  });

  customNotificationTimeInput.addEventListener('change', saveNotificationSettings);

  function saveNotificationSettings() {
    const settings = {
      time: notificationTimeSelect.value,
      customTime: customNotificationTimeInput.value
    };
    
    chrome.storage.sync.set({ notificationSettings: settings });
  }

  showHideTokenBtn.addEventListener('click', function() {
    if (telegramBotTokenInput.type === 'password') {
      telegramBotTokenInput.type = 'text';
      showHideTokenBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
      telegramBotTokenInput.type = 'password';
      showHideTokenBtn.innerHTML = '<i class="fas fa-eye"></i>';
    }
  });

  saveTelegramSettingsBtn.addEventListener('click', function() {
    const settings = {
      botToken: telegramBotTokenInput.value,
      chatId: telegramChatIdInput.value
    };
    
    chrome.storage.sync.set({ telegramSettings: settings }, function() {
      alert('Cài đặt Telegram đã được lưu!');
    });
  });

  resetTelegramSettingsBtn.addEventListener('click', function() {
    telegramBotTokenInput.value = '';
    telegramChatIdInput.value = '';
    chrome.storage.sync.remove('telegramSettings', function() {
      alert('Cài đặt Telegram đã được xóa!');
    });
  });

  exportDataBtn.addEventListener('click', function() {
    chrome.storage.sync.get(['tasks', 'notificationSettings', 'telegramSettings'], function(data) {
      const exportData = JSON.stringify(data);
      const blob = new Blob([exportData], {type: 'application/json'});
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = 'quan_ly_cong_viec_backup_' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a);
      a.click();
      
      setTimeout(function() {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 0);
    });
  });

  importDataBtn.addEventListener('click', function() {
    importFileInput.click();
  });

  importFileInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
      try {
        const data = JSON.parse(e.target.result);
        
        chrome.storage.sync.set(data, function() {
          alert('Dữ liệu đã được nhập thành công!');
          loadSettings();
        });
      } catch (error) {
        alert('Lỗi khi nhập dữ liệu: ' + error.message);
      }
    };
    reader.readAsText(file);
  });

  showPanelBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: 'showPanel'});
    });
  });

  // Initialize
  loadSettings();
});
